matlab -nojvm -nodisplay -nosplash -r 'tree_148'
rm 148.train_all.dat
rm 148.test_all.dat
rm tree_148.m

matlab -nojvm -nodisplay -nosplash -r 'tree_149'
rm 149.train_all.dat
rm 149.test_all.dat
rm tree_149.m

matlab -nojvm -nodisplay -nosplash -r 'tree_150'
rm 150.train_all.dat
rm 150.test_all.dat
rm tree_150.m

matlab -nojvm -nodisplay -nosplash -r 'tree_151'
rm 151.train_all.dat
rm 151.test_all.dat
rm tree_151.m

matlab -nojvm -nodisplay -nosplash -r 'tree_152'
rm 152.train_all.dat
rm 152.test_all.dat
rm tree_152.m

matlab -nojvm -nodisplay -nosplash -r 'tree_153'
rm 153.train_all.dat
rm 153.test_all.dat
rm tree_153.m

matlab -nojvm -nodisplay -nosplash -r 'tree_154'
rm 154.train_all.dat
rm 154.test_all.dat
rm tree_154.m

matlab -nojvm -nodisplay -nosplash -r 'tree_155'
rm 155.train_all.dat
rm 155.test_all.dat
rm tree_155.m

matlab -nojvm -nodisplay -nosplash -r 'tree_156'
rm 156.train_all.dat
rm 156.test_all.dat
rm tree_156.m

matlab -nojvm -nodisplay -nosplash -r 'tree_157'
rm 157.train_all.dat
rm 157.test_all.dat
rm tree_157.m

matlab -nojvm -nodisplay -nosplash -r 'tree_158'
rm 158.train_all.dat
rm 158.test_all.dat
rm tree_158.m

matlab -nojvm -nodisplay -nosplash -r 'tree_159'
rm 159.train_all.dat
rm 159.test_all.dat
rm tree_159.m

matlab -nojvm -nodisplay -nosplash -r 'tree_160'
rm 160.train_all.dat
rm 160.test_all.dat
rm tree_160.m

matlab -nojvm -nodisplay -nosplash -r 'tree_161'
rm 161.train_all.dat
rm 161.test_all.dat
rm tree_161.m

matlab -nojvm -nodisplay -nosplash -r 'tree_162'
rm 162.train_all.dat
rm 162.test_all.dat
rm tree_162.m

matlab -nojvm -nodisplay -nosplash -r 'tree_163'
rm 163.train_all.dat
rm 163.test_all.dat
rm tree_163.m

matlab -nojvm -nodisplay -nosplash -r 'tree_164'
rm 164.train_all.dat
rm 164.test_all.dat
rm tree_164.m

matlab -nojvm -nodisplay -nosplash -r 'tree_165'
rm 165.train_all.dat
rm 165.test_all.dat
rm tree_165.m

matlab -nojvm -nodisplay -nosplash -r 'tree_166'
rm 166.train_all.dat
rm 166.test_all.dat
rm tree_166.m

matlab -nojvm -nodisplay -nosplash -r 'tree_167'
rm 167.train_all.dat
rm 167.test_all.dat
rm tree_167.m

matlab -nojvm -nodisplay -nosplash -r 'tree_168'
rm 168.train_all.dat
rm 168.test_all.dat
rm tree_168.m

matlab -nojvm -nodisplay -nosplash -r 'tree_169'
rm 169.train_all.dat
rm 169.test_all.dat
rm tree_169.m

matlab -nojvm -nodisplay -nosplash -r 'tree_170'
rm 170.train_all.dat
rm 170.test_all.dat
rm tree_170.m

matlab -nojvm -nodisplay -nosplash -r 'tree_171'
rm 171.train_all.dat
rm 171.test_all.dat
rm tree_171.m

matlab -nojvm -nodisplay -nosplash -r 'tree_172'
rm 172.train_all.dat
rm 172.test_all.dat
rm tree_172.m

matlab -nojvm -nodisplay -nosplash -r 'tree_173'
rm 173.train_all.dat
rm 173.test_all.dat
rm tree_173.m

matlab -nojvm -nodisplay -nosplash -r 'tree_174'
rm 174.train_all.dat
rm 174.test_all.dat
rm tree_174.m

matlab -nojvm -nodisplay -nosplash -r 'tree_175'
rm 175.train_all.dat
rm 175.test_all.dat
rm tree_175.m

matlab -nojvm -nodisplay -nosplash -r 'tree_176'
rm 176.train_all.dat
rm 176.test_all.dat
rm tree_176.m

matlab -nojvm -nodisplay -nosplash -r 'tree_177'
rm 177.train_all.dat
rm 177.test_all.dat
rm tree_177.m

matlab -nojvm -nodisplay -nosplash -r 'tree_178'
rm 178.train_all.dat
rm 178.test_all.dat
rm tree_178.m

matlab -nojvm -nodisplay -nosplash -r 'tree_179'
rm 179.train_all.dat
rm 179.test_all.dat
rm tree_179.m

matlab -nojvm -nodisplay -nosplash -r 'tree_180'
rm 180.train_all.dat
rm 180.test_all.dat
rm tree_180.m

matlab -nojvm -nodisplay -nosplash -r 'tree_181'
rm 181.train_all.dat
rm 181.test_all.dat
rm tree_181.m

matlab -nojvm -nodisplay -nosplash -r 'tree_182'
rm 182.train_all.dat
rm 182.test_all.dat
rm tree_182.m

matlab -nojvm -nodisplay -nosplash -r 'tree_183'
rm 183.train_all.dat
rm 183.test_all.dat
rm tree_183.m

matlab -nojvm -nodisplay -nosplash -r 'tree_184'
rm 184.train_all.dat
rm 184.test_all.dat
rm tree_184.m

matlab -nojvm -nodisplay -nosplash -r 'tree_185'
rm 185.train_all.dat
rm 185.test_all.dat
rm tree_185.m

matlab -nojvm -nodisplay -nosplash -r 'tree_186'
rm 186.train_all.dat
rm 186.test_all.dat
rm tree_186.m

matlab -nojvm -nodisplay -nosplash -r 'tree_187'
rm 187.train_all.dat
rm 187.test_all.dat
rm tree_187.m

matlab -nojvm -nodisplay -nosplash -r 'tree_188'
rm 188.train_all.dat
rm 188.test_all.dat
rm tree_188.m

matlab -nojvm -nodisplay -nosplash -r 'tree_189'
rm 189.train_all.dat
rm 189.test_all.dat
rm tree_189.m

matlab -nojvm -nodisplay -nosplash -r 'tree_190'
rm 190.train_all.dat
rm 190.test_all.dat
rm tree_190.m

matlab -nojvm -nodisplay -nosplash -r 'tree_191'
rm 191.train_all.dat
rm 191.test_all.dat
rm tree_191.m

matlab -nojvm -nodisplay -nosplash -r 'tree_192'
rm 192.train_all.dat
rm 192.test_all.dat
rm tree_192.m

matlab -nojvm -nodisplay -nosplash -r 'tree_193'
rm 193.train_all.dat
rm 193.test_all.dat
rm tree_193.m

matlab -nojvm -nodisplay -nosplash -r 'tree_194'
rm 194.train_all.dat
rm 194.test_all.dat
rm tree_194.m

matlab -nojvm -nodisplay -nosplash -r 'tree_195'
rm 195.train_all.dat
rm 195.test_all.dat
rm tree_195.m

matlab -nojvm -nodisplay -nosplash -r 'tree_196'
rm 196.train_all.dat
rm 196.test_all.dat
rm tree_196.m

