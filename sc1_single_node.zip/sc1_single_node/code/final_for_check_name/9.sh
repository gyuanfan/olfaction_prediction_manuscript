matlab -nojvm -nodisplay -nosplash -r 'tree_393'
rm 393.train_all.dat
rm 393.test_all.dat
rm tree_393.m

matlab -nojvm -nodisplay -nosplash -r 'tree_394'
rm 394.train_all.dat
rm 394.test_all.dat
rm tree_394.m

matlab -nojvm -nodisplay -nosplash -r 'tree_395'
rm 395.train_all.dat
rm 395.test_all.dat
rm tree_395.m

matlab -nojvm -nodisplay -nosplash -r 'tree_396'
rm 396.train_all.dat
rm 396.test_all.dat
rm tree_396.m

matlab -nojvm -nodisplay -nosplash -r 'tree_397'
rm 397.train_all.dat
rm 397.test_all.dat
rm tree_397.m

matlab -nojvm -nodisplay -nosplash -r 'tree_398'
rm 398.train_all.dat
rm 398.test_all.dat
rm tree_398.m

matlab -nojvm -nodisplay -nosplash -r 'tree_399'
rm 399.train_all.dat
rm 399.test_all.dat
rm tree_399.m

matlab -nojvm -nodisplay -nosplash -r 'tree_400'
rm 400.train_all.dat
rm 400.test_all.dat
rm tree_400.m

matlab -nojvm -nodisplay -nosplash -r 'tree_401'
rm 401.train_all.dat
rm 401.test_all.dat
rm tree_401.m

matlab -nojvm -nodisplay -nosplash -r 'tree_402'
rm 402.train_all.dat
rm 402.test_all.dat
rm tree_402.m

matlab -nojvm -nodisplay -nosplash -r 'tree_403'
rm 403.train_all.dat
rm 403.test_all.dat
rm tree_403.m

matlab -nojvm -nodisplay -nosplash -r 'tree_404'
rm 404.train_all.dat
rm 404.test_all.dat
rm tree_404.m

matlab -nojvm -nodisplay -nosplash -r 'tree_405'
rm 405.train_all.dat
rm 405.test_all.dat
rm tree_405.m

matlab -nojvm -nodisplay -nosplash -r 'tree_406'
rm 406.train_all.dat
rm 406.test_all.dat
rm tree_406.m

matlab -nojvm -nodisplay -nosplash -r 'tree_407'
rm 407.train_all.dat
rm 407.test_all.dat
rm tree_407.m

matlab -nojvm -nodisplay -nosplash -r 'tree_408'
rm 408.train_all.dat
rm 408.test_all.dat
rm tree_408.m

matlab -nojvm -nodisplay -nosplash -r 'tree_409'
rm 409.train_all.dat
rm 409.test_all.dat
rm tree_409.m

matlab -nojvm -nodisplay -nosplash -r 'tree_410'
rm 410.train_all.dat
rm 410.test_all.dat
rm tree_410.m

matlab -nojvm -nodisplay -nosplash -r 'tree_411'
rm 411.train_all.dat
rm 411.test_all.dat
rm tree_411.m

matlab -nojvm -nodisplay -nosplash -r 'tree_412'
rm 412.train_all.dat
rm 412.test_all.dat
rm tree_412.m

matlab -nojvm -nodisplay -nosplash -r 'tree_413'
rm 413.train_all.dat
rm 413.test_all.dat
rm tree_413.m

matlab -nojvm -nodisplay -nosplash -r 'tree_414'
rm 414.train_all.dat
rm 414.test_all.dat
rm tree_414.m

matlab -nojvm -nodisplay -nosplash -r 'tree_415'
rm 415.train_all.dat
rm 415.test_all.dat
rm tree_415.m

matlab -nojvm -nodisplay -nosplash -r 'tree_416'
rm 416.train_all.dat
rm 416.test_all.dat
rm tree_416.m

matlab -nojvm -nodisplay -nosplash -r 'tree_417'
rm 417.train_all.dat
rm 417.test_all.dat
rm tree_417.m

matlab -nojvm -nodisplay -nosplash -r 'tree_418'
rm 418.train_all.dat
rm 418.test_all.dat
rm tree_418.m

matlab -nojvm -nodisplay -nosplash -r 'tree_419'
rm 419.train_all.dat
rm 419.test_all.dat
rm tree_419.m

matlab -nojvm -nodisplay -nosplash -r 'tree_420'
rm 420.train_all.dat
rm 420.test_all.dat
rm tree_420.m

matlab -nojvm -nodisplay -nosplash -r 'tree_421'
rm 421.train_all.dat
rm 421.test_all.dat
rm tree_421.m

matlab -nojvm -nodisplay -nosplash -r 'tree_422'
rm 422.train_all.dat
rm 422.test_all.dat
rm tree_422.m

matlab -nojvm -nodisplay -nosplash -r 'tree_423'
rm 423.train_all.dat
rm 423.test_all.dat
rm tree_423.m

matlab -nojvm -nodisplay -nosplash -r 'tree_424'
rm 424.train_all.dat
rm 424.test_all.dat
rm tree_424.m

matlab -nojvm -nodisplay -nosplash -r 'tree_425'
rm 425.train_all.dat
rm 425.test_all.dat
rm tree_425.m

matlab -nojvm -nodisplay -nosplash -r 'tree_426'
rm 426.train_all.dat
rm 426.test_all.dat
rm tree_426.m

matlab -nojvm -nodisplay -nosplash -r 'tree_427'
rm 427.train_all.dat
rm 427.test_all.dat
rm tree_427.m

matlab -nojvm -nodisplay -nosplash -r 'tree_428'
rm 428.train_all.dat
rm 428.test_all.dat
rm tree_428.m

matlab -nojvm -nodisplay -nosplash -r 'tree_429'
rm 429.train_all.dat
rm 429.test_all.dat
rm tree_429.m

matlab -nojvm -nodisplay -nosplash -r 'tree_430'
rm 430.train_all.dat
rm 430.test_all.dat
rm tree_430.m

matlab -nojvm -nodisplay -nosplash -r 'tree_431'
rm 431.train_all.dat
rm 431.test_all.dat
rm tree_431.m

matlab -nojvm -nodisplay -nosplash -r 'tree_432'
rm 432.train_all.dat
rm 432.test_all.dat
rm tree_432.m

matlab -nojvm -nodisplay -nosplash -r 'tree_433'
rm 433.train_all.dat
rm 433.test_all.dat
rm tree_433.m

matlab -nojvm -nodisplay -nosplash -r 'tree_434'
rm 434.train_all.dat
rm 434.test_all.dat
rm tree_434.m

matlab -nojvm -nodisplay -nosplash -r 'tree_435'
rm 435.train_all.dat
rm 435.test_all.dat
rm tree_435.m

matlab -nojvm -nodisplay -nosplash -r 'tree_436'
rm 436.train_all.dat
rm 436.test_all.dat
rm tree_436.m

matlab -nojvm -nodisplay -nosplash -r 'tree_437'
rm 437.train_all.dat
rm 437.test_all.dat
rm tree_437.m

matlab -nojvm -nodisplay -nosplash -r 'tree_438'
rm 438.train_all.dat
rm 438.test_all.dat
rm tree_438.m

matlab -nojvm -nodisplay -nosplash -r 'tree_439'
rm 439.train_all.dat
rm 439.test_all.dat
rm tree_439.m

matlab -nojvm -nodisplay -nosplash -r 'tree_440'
rm 440.train_all.dat
rm 440.test_all.dat
rm tree_440.m

matlab -nojvm -nodisplay -nosplash -r 'tree_441'
rm 441.train_all.dat
rm 441.test_all.dat
rm tree_441.m

