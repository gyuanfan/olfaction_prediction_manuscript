matlab -nojvm -nodisplay -nosplash -r 'tree_1'
rm 1.train_all.dat
rm 1.test_all.dat
rm tree_1.m

matlab -nojvm -nodisplay -nosplash -r 'tree_2'
rm 2.train_all.dat
rm 2.test_all.dat
rm tree_2.m

matlab -nojvm -nodisplay -nosplash -r 'tree_3'
rm 3.train_all.dat
rm 3.test_all.dat
rm tree_3.m

matlab -nojvm -nodisplay -nosplash -r 'tree_4'
rm 4.train_all.dat
rm 4.test_all.dat
rm tree_4.m

matlab -nojvm -nodisplay -nosplash -r 'tree_5'
rm 5.train_all.dat
rm 5.test_all.dat
rm tree_5.m

matlab -nojvm -nodisplay -nosplash -r 'tree_6'
rm 6.train_all.dat
rm 6.test_all.dat
rm tree_6.m

matlab -nojvm -nodisplay -nosplash -r 'tree_7'
rm 7.train_all.dat
rm 7.test_all.dat
rm tree_7.m

matlab -nojvm -nodisplay -nosplash -r 'tree_8'
rm 8.train_all.dat
rm 8.test_all.dat
rm tree_8.m

matlab -nojvm -nodisplay -nosplash -r 'tree_9'
rm 9.train_all.dat
rm 9.test_all.dat
rm tree_9.m

matlab -nojvm -nodisplay -nosplash -r 'tree_10'
rm 10.train_all.dat
rm 10.test_all.dat
rm tree_10.m

matlab -nojvm -nodisplay -nosplash -r 'tree_11'
rm 11.train_all.dat
rm 11.test_all.dat
rm tree_11.m

matlab -nojvm -nodisplay -nosplash -r 'tree_12'
rm 12.train_all.dat
rm 12.test_all.dat
rm tree_12.m

matlab -nojvm -nodisplay -nosplash -r 'tree_13'
rm 13.train_all.dat
rm 13.test_all.dat
rm tree_13.m

matlab -nojvm -nodisplay -nosplash -r 'tree_14'
rm 14.train_all.dat
rm 14.test_all.dat
rm tree_14.m

matlab -nojvm -nodisplay -nosplash -r 'tree_15'
rm 15.train_all.dat
rm 15.test_all.dat
rm tree_15.m

matlab -nojvm -nodisplay -nosplash -r 'tree_16'
rm 16.train_all.dat
rm 16.test_all.dat
rm tree_16.m

matlab -nojvm -nodisplay -nosplash -r 'tree_17'
rm 17.train_all.dat
rm 17.test_all.dat
rm tree_17.m

matlab -nojvm -nodisplay -nosplash -r 'tree_18'
rm 18.train_all.dat
rm 18.test_all.dat
rm tree_18.m

matlab -nojvm -nodisplay -nosplash -r 'tree_19'
rm 19.train_all.dat
rm 19.test_all.dat
rm tree_19.m

matlab -nojvm -nodisplay -nosplash -r 'tree_20'
rm 20.train_all.dat
rm 20.test_all.dat
rm tree_20.m

matlab -nojvm -nodisplay -nosplash -r 'tree_21'
rm 21.train_all.dat
rm 21.test_all.dat
rm tree_21.m

matlab -nojvm -nodisplay -nosplash -r 'tree_22'
rm 22.train_all.dat
rm 22.test_all.dat
rm tree_22.m

matlab -nojvm -nodisplay -nosplash -r 'tree_23'
rm 23.train_all.dat
rm 23.test_all.dat
rm tree_23.m

matlab -nojvm -nodisplay -nosplash -r 'tree_24'
rm 24.train_all.dat
rm 24.test_all.dat
rm tree_24.m

matlab -nojvm -nodisplay -nosplash -r 'tree_25'
rm 25.train_all.dat
rm 25.test_all.dat
rm tree_25.m

matlab -nojvm -nodisplay -nosplash -r 'tree_26'
rm 26.train_all.dat
rm 26.test_all.dat
rm tree_26.m

matlab -nojvm -nodisplay -nosplash -r 'tree_27'
rm 27.train_all.dat
rm 27.test_all.dat
rm tree_27.m

matlab -nojvm -nodisplay -nosplash -r 'tree_28'
rm 28.train_all.dat
rm 28.test_all.dat
rm tree_28.m

matlab -nojvm -nodisplay -nosplash -r 'tree_29'
rm 29.train_all.dat
rm 29.test_all.dat
rm tree_29.m

matlab -nojvm -nodisplay -nosplash -r 'tree_30'
rm 30.train_all.dat
rm 30.test_all.dat
rm tree_30.m

matlab -nojvm -nodisplay -nosplash -r 'tree_31'
rm 31.train_all.dat
rm 31.test_all.dat
rm tree_31.m

matlab -nojvm -nodisplay -nosplash -r 'tree_32'
rm 32.train_all.dat
rm 32.test_all.dat
rm tree_32.m

matlab -nojvm -nodisplay -nosplash -r 'tree_33'
rm 33.train_all.dat
rm 33.test_all.dat
rm tree_33.m

matlab -nojvm -nodisplay -nosplash -r 'tree_34'
rm 34.train_all.dat
rm 34.test_all.dat
rm tree_34.m

matlab -nojvm -nodisplay -nosplash -r 'tree_35'
rm 35.train_all.dat
rm 35.test_all.dat
rm tree_35.m

matlab -nojvm -nodisplay -nosplash -r 'tree_36'
rm 36.train_all.dat
rm 36.test_all.dat
rm tree_36.m

matlab -nojvm -nodisplay -nosplash -r 'tree_37'
rm 37.train_all.dat
rm 37.test_all.dat
rm tree_37.m

matlab -nojvm -nodisplay -nosplash -r 'tree_38'
rm 38.train_all.dat
rm 38.test_all.dat
rm tree_38.m

matlab -nojvm -nodisplay -nosplash -r 'tree_39'
rm 39.train_all.dat
rm 39.test_all.dat
rm tree_39.m

matlab -nojvm -nodisplay -nosplash -r 'tree_40'
rm 40.train_all.dat
rm 40.test_all.dat
rm tree_40.m

matlab -nojvm -nodisplay -nosplash -r 'tree_41'
rm 41.train_all.dat
rm 41.test_all.dat
rm tree_41.m

matlab -nojvm -nodisplay -nosplash -r 'tree_42'
rm 42.train_all.dat
rm 42.test_all.dat
rm tree_42.m

matlab -nojvm -nodisplay -nosplash -r 'tree_43'
rm 43.train_all.dat
rm 43.test_all.dat
rm tree_43.m

matlab -nojvm -nodisplay -nosplash -r 'tree_44'
rm 44.train_all.dat
rm 44.test_all.dat
rm tree_44.m

matlab -nojvm -nodisplay -nosplash -r 'tree_45'
rm 45.train_all.dat
rm 45.test_all.dat
rm tree_45.m

matlab -nojvm -nodisplay -nosplash -r 'tree_46'
rm 46.train_all.dat
rm 46.test_all.dat
rm tree_46.m

matlab -nojvm -nodisplay -nosplash -r 'tree_47'
rm 47.train_all.dat
rm 47.test_all.dat
rm tree_47.m

matlab -nojvm -nodisplay -nosplash -r 'tree_48'
rm 48.train_all.dat
rm 48.test_all.dat
rm tree_48.m

matlab -nojvm -nodisplay -nosplash -r 'tree_49'
rm 49.train_all.dat
rm 49.test_all.dat
rm tree_49.m

