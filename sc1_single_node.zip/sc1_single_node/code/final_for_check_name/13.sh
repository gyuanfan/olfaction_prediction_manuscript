matlab -nojvm -nodisplay -nosplash -r 'tree_589'
rm 589.train_all.dat
rm 589.test_all.dat
rm tree_589.m

matlab -nojvm -nodisplay -nosplash -r 'tree_590'
rm 590.train_all.dat
rm 590.test_all.dat
rm tree_590.m

matlab -nojvm -nodisplay -nosplash -r 'tree_591'
rm 591.train_all.dat
rm 591.test_all.dat
rm tree_591.m

matlab -nojvm -nodisplay -nosplash -r 'tree_592'
rm 592.train_all.dat
rm 592.test_all.dat
rm tree_592.m

matlab -nojvm -nodisplay -nosplash -r 'tree_593'
rm 593.train_all.dat
rm 593.test_all.dat
rm tree_593.m

matlab -nojvm -nodisplay -nosplash -r 'tree_594'
rm 594.train_all.dat
rm 594.test_all.dat
rm tree_594.m

matlab -nojvm -nodisplay -nosplash -r 'tree_595'
rm 595.train_all.dat
rm 595.test_all.dat
rm tree_595.m

matlab -nojvm -nodisplay -nosplash -r 'tree_596'
rm 596.train_all.dat
rm 596.test_all.dat
rm tree_596.m

matlab -nojvm -nodisplay -nosplash -r 'tree_597'
rm 597.train_all.dat
rm 597.test_all.dat
rm tree_597.m

matlab -nojvm -nodisplay -nosplash -r 'tree_598'
rm 598.train_all.dat
rm 598.test_all.dat
rm tree_598.m

matlab -nojvm -nodisplay -nosplash -r 'tree_599'
rm 599.train_all.dat
rm 599.test_all.dat
rm tree_599.m

matlab -nojvm -nodisplay -nosplash -r 'tree_600'
rm 600.train_all.dat
rm 600.test_all.dat
rm tree_600.m

matlab -nojvm -nodisplay -nosplash -r 'tree_601'
rm 601.train_all.dat
rm 601.test_all.dat
rm tree_601.m

matlab -nojvm -nodisplay -nosplash -r 'tree_602'
rm 602.train_all.dat
rm 602.test_all.dat
rm tree_602.m

matlab -nojvm -nodisplay -nosplash -r 'tree_603'
rm 603.train_all.dat
rm 603.test_all.dat
rm tree_603.m

matlab -nojvm -nodisplay -nosplash -r 'tree_604'
rm 604.train_all.dat
rm 604.test_all.dat
rm tree_604.m

matlab -nojvm -nodisplay -nosplash -r 'tree_605'
rm 605.train_all.dat
rm 605.test_all.dat
rm tree_605.m

matlab -nojvm -nodisplay -nosplash -r 'tree_606'
rm 606.train_all.dat
rm 606.test_all.dat
rm tree_606.m

matlab -nojvm -nodisplay -nosplash -r 'tree_607'
rm 607.train_all.dat
rm 607.test_all.dat
rm tree_607.m

matlab -nojvm -nodisplay -nosplash -r 'tree_608'
rm 608.train_all.dat
rm 608.test_all.dat
rm tree_608.m

matlab -nojvm -nodisplay -nosplash -r 'tree_609'
rm 609.train_all.dat
rm 609.test_all.dat
rm tree_609.m

matlab -nojvm -nodisplay -nosplash -r 'tree_610'
rm 610.train_all.dat
rm 610.test_all.dat
rm tree_610.m

matlab -nojvm -nodisplay -nosplash -r 'tree_611'
rm 611.train_all.dat
rm 611.test_all.dat
rm tree_611.m

matlab -nojvm -nodisplay -nosplash -r 'tree_612'
rm 612.train_all.dat
rm 612.test_all.dat
rm tree_612.m

matlab -nojvm -nodisplay -nosplash -r 'tree_613'
rm 613.train_all.dat
rm 613.test_all.dat
rm tree_613.m

matlab -nojvm -nodisplay -nosplash -r 'tree_614'
rm 614.train_all.dat
rm 614.test_all.dat
rm tree_614.m

matlab -nojvm -nodisplay -nosplash -r 'tree_615'
rm 615.train_all.dat
rm 615.test_all.dat
rm tree_615.m

matlab -nojvm -nodisplay -nosplash -r 'tree_616'
rm 616.train_all.dat
rm 616.test_all.dat
rm tree_616.m

matlab -nojvm -nodisplay -nosplash -r 'tree_617'
rm 617.train_all.dat
rm 617.test_all.dat
rm tree_617.m

matlab -nojvm -nodisplay -nosplash -r 'tree_618'
rm 618.train_all.dat
rm 618.test_all.dat
rm tree_618.m

matlab -nojvm -nodisplay -nosplash -r 'tree_619'
rm 619.train_all.dat
rm 619.test_all.dat
rm tree_619.m

matlab -nojvm -nodisplay -nosplash -r 'tree_620'
rm 620.train_all.dat
rm 620.test_all.dat
rm tree_620.m

matlab -nojvm -nodisplay -nosplash -r 'tree_621'
rm 621.train_all.dat
rm 621.test_all.dat
rm tree_621.m

matlab -nojvm -nodisplay -nosplash -r 'tree_622'
rm 622.train_all.dat
rm 622.test_all.dat
rm tree_622.m

matlab -nojvm -nodisplay -nosplash -r 'tree_623'
rm 623.train_all.dat
rm 623.test_all.dat
rm tree_623.m

matlab -nojvm -nodisplay -nosplash -r 'tree_624'
rm 624.train_all.dat
rm 624.test_all.dat
rm tree_624.m

matlab -nojvm -nodisplay -nosplash -r 'tree_625'
rm 625.train_all.dat
rm 625.test_all.dat
rm tree_625.m

matlab -nojvm -nodisplay -nosplash -r 'tree_626'
rm 626.train_all.dat
rm 626.test_all.dat
rm tree_626.m

matlab -nojvm -nodisplay -nosplash -r 'tree_627'
rm 627.train_all.dat
rm 627.test_all.dat
rm tree_627.m

matlab -nojvm -nodisplay -nosplash -r 'tree_628'
rm 628.train_all.dat
rm 628.test_all.dat
rm tree_628.m

matlab -nojvm -nodisplay -nosplash -r 'tree_629'
rm 629.train_all.dat
rm 629.test_all.dat
rm tree_629.m

matlab -nojvm -nodisplay -nosplash -r 'tree_630'
rm 630.train_all.dat
rm 630.test_all.dat
rm tree_630.m

matlab -nojvm -nodisplay -nosplash -r 'tree_631'
rm 631.train_all.dat
rm 631.test_all.dat
rm tree_631.m

matlab -nojvm -nodisplay -nosplash -r 'tree_632'
rm 632.train_all.dat
rm 632.test_all.dat
rm tree_632.m

matlab -nojvm -nodisplay -nosplash -r 'tree_633'
rm 633.train_all.dat
rm 633.test_all.dat
rm tree_633.m

matlab -nojvm -nodisplay -nosplash -r 'tree_634'
rm 634.train_all.dat
rm 634.test_all.dat
rm tree_634.m

matlab -nojvm -nodisplay -nosplash -r 'tree_635'
rm 635.train_all.dat
rm 635.test_all.dat
rm tree_635.m

matlab -nojvm -nodisplay -nosplash -r 'tree_636'
rm 636.train_all.dat
rm 636.test_all.dat
rm tree_636.m

matlab -nojvm -nodisplay -nosplash -r 'tree_637'
rm 637.train_all.dat
rm 637.test_all.dat
rm tree_637.m

