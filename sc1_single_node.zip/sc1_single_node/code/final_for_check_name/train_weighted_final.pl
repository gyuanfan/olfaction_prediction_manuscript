#!/usr/bin/perl


if (scalar(@ARGV)<1){
	print "perl train_weighted.pl <factor-contribution-individual>\n";
	die;
}

mkdir result;

## record parameter
#
system "rm *dat";
system "rm tree*m";
system "rm *.sh";

$factor=$ARGV[0];
@target_dir_list=glob "../../TARGET_final_for_check/*";
$data_file="../../REF/name_features.txt";
open DATA, $data_file;
while ($line=<DATA>){
	chomp $line;
	@table=split "\t", $line;
	$name=shift @table;
	if (exists $ref{$name}){
		print "same chemical occured twice in data\n";
	}else{
		$i=1;
		foreach $val (@table){
			$ref{$name}.="\t$val";
			$i++;
		}
	}
}
close DATA;

@che_list=keys %ref;
@che_list=sort{$a<=>$b}@che_list;


$rand=1;
$shrand=1;
@test_list=();
open NEW, ">test_list.txt";
open TEST, "../../REF/CID_leaderboard.txt" or die;
while ($line=<TEST>){
	chomp $line;
	$line=~s/\s//g;
	push @test_list, $line;
	print NEW "$line\n";
}
close TEST;



open TEST, "../../REF/CID_testset.txt" or die;
while ($line=<TEST>){
	chomp $line;
	$line=~s/\s//g;
	push @test_list, $line;
	print NEW "$line\n";
}
close TEST;
close NEW;

	
$i=1;
foreach $aaa (@test_list){
	$map[$i]=$aaa;
	$i++;
}


foreach $target_dir (@target_dir_list){

	@t=split '/', $target_dir;
	$outputfile=pop @t;
	@mat=glob "$target_dir/*";


	## generate train_all for this directory;;

	%value=();
	%count=();
	%value_new=();
	%count_new=();
	foreach $file (@mat){ 
		open FILE, "$file" or die;
		while ($line=<FILE>){
			chomp $line;
			@table=split "\t", $line;
			if ($table[1] eq "NaN"){
			}else{
				$value{$table[0]}+=$table[1];
				$count{$table[0]}++;
			}
		}
		close FILE;

		$newfile=$file;
		$newfile=~s/TARGET_final_for_check/TARGET_final_for_check_both/g;
		
		open FILE, "$newfile" or die;
		while ($line=<FILE>){
			chomp $line;
			@table=split "\t", $line;
			if ($table[1] eq "NaN"){
			}else{
				$value_new{$table[0]}+=$table[1];
				$count_new{$table[0]}++;
			}
		}
		close FILE;





	}


	foreach $file (@mat){
		open TRAIN, ">${rand}.train_all.dat" or die;
		open TEST, ">${rand}.test_all.dat" or die;
		

		open FILE, "$file" or die;
		%test=();
		while ($line=<FILE>){
			chomp $line;
			@table=split "\t", $line;
			if ($table[1] eq "NaN"){}else{
				$test{$table[0]}=$table[1];
			}
		}
		close FILE;


		$newfile=$file;
		$newfile=~s/TARGET_final_for_check/TARGET_final_for_check_both/g;
		open FILE, "$newfile" or die;
		%test_new=();
		while ($line=<FILE>){
			chomp $line;
			@table=split "\t", $line;
			if ($table[1] eq "NaN"){}else{
				$test_new{$table[0]}=$table[1];
			}
		}
		close FILE;



		
		foreach $che (@che_list){
			if (defined $value{$che}){
				if (defined $test{$che}){
					$test_val=$test{$che};
				}else{
					
					$test_val=0;
				}
				$ratio=(scalar(keys %test))/(scalar(keys %value))*$factor;	
				print "$ratio\ori\n";
					
				$val=(1-$ratio)*$value{$che}/$count{$che}+$ratio*$test_val;
				print TRAIN "$val";
				@t=split "\t", $ref{$che};
				shift @t;
				$i=1;
				foreach $aaa (@t){
					print TRAIN "\t$aaa";
					$i++;
				}

				print TRAIN "\n";
			}
			if (($file=~/INTENSITY/)||($file=~/VALENCE/)){}else{
			$ratio=(scalar(keys %test_new))/(scalar(keys %value_new))*$factor;	
			print "$ratio\tboth\n";
			if (defined $value_new{$che}){
				if (defined $test_new{$che}){
					$test_val=$test_new{$che};
				}else{
					
					$test_val=0;
				}
					
				$val=(1-$ratio)*$value_new{$che}/$count_new{$che}+$ratio*$test_val;

				print TRAIN "$val";
				@t=split "\t", $ref{$che};
				shift @t;
				$i=1;
				foreach $aaa (@t){
					print TRAIN "\t$aaa";
					$i++;
				}

				print TRAIN "\n";
			}
			}
		}
		foreach $che (@test_list){
				print TEST "0";
				@t=split "\t", $ref{$che};
				shift @t;
				$i=1;
				foreach $aaa (@t){
					print TEST "\t$aaa";
					$i++;
				}

				print TEST "\n";
		}
		close TRAIN;
		close TEST;
		





		
			
		@t=split '/', $file;
		$id=pop @t;
		
		$des=pop@t;



		@t=split '\.train', $id;
		$id=shift @t;


		
		open TREE, ">tree_${rand}.m" or die;
		print TREE "
			train=load('${rand}.train_all.dat');
			test=load('${rand}.test_all.dat');
			n_column=size(train,2);

			y_train_target=train(:,1);
			y_train_data=train(:,2:n_column);
			B = TreeBagger(100,y_train_data,y_train_target,'method','regression');
			y_test_data=test(:,2:n_column);
			 pred=B.predict(y_test_data);
			save 'result/${des}.${id}.result' pred -ASCII
			exit;
		";
		close TREE;

		open BASH, ">>${shrand}.sh" or die;
		print BASH "matlab -nojvm -nodisplay -nosplash -r '"; print BASH "tree_${rand}"; print BASH "'\n";
		print BASH "rm ${rand}.train_all.dat\n";
		print BASH "rm ${rand}.test_all.dat\n";
		print BASH "rm tree_${rand}.m\n\n";
		close BASH;
		
		$rand++;


		$des_list{$des}=0;
		$id_list{$id}=0;
	
	}
	system "chmod +x ${shrand}.sh";
	$shrand++;

}


$i=1;
while ($i<$shrand){
	system "./${i}.sh";
	$i++;
}

