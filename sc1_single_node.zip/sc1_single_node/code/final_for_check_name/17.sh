matlab -nojvm -nodisplay -nosplash -r 'tree_785'
rm 785.train_all.dat
rm 785.test_all.dat
rm tree_785.m

matlab -nojvm -nodisplay -nosplash -r 'tree_786'
rm 786.train_all.dat
rm 786.test_all.dat
rm tree_786.m

matlab -nojvm -nodisplay -nosplash -r 'tree_787'
rm 787.train_all.dat
rm 787.test_all.dat
rm tree_787.m

matlab -nojvm -nodisplay -nosplash -r 'tree_788'
rm 788.train_all.dat
rm 788.test_all.dat
rm tree_788.m

matlab -nojvm -nodisplay -nosplash -r 'tree_789'
rm 789.train_all.dat
rm 789.test_all.dat
rm tree_789.m

matlab -nojvm -nodisplay -nosplash -r 'tree_790'
rm 790.train_all.dat
rm 790.test_all.dat
rm tree_790.m

matlab -nojvm -nodisplay -nosplash -r 'tree_791'
rm 791.train_all.dat
rm 791.test_all.dat
rm tree_791.m

matlab -nojvm -nodisplay -nosplash -r 'tree_792'
rm 792.train_all.dat
rm 792.test_all.dat
rm tree_792.m

matlab -nojvm -nodisplay -nosplash -r 'tree_793'
rm 793.train_all.dat
rm 793.test_all.dat
rm tree_793.m

matlab -nojvm -nodisplay -nosplash -r 'tree_794'
rm 794.train_all.dat
rm 794.test_all.dat
rm tree_794.m

matlab -nojvm -nodisplay -nosplash -r 'tree_795'
rm 795.train_all.dat
rm 795.test_all.dat
rm tree_795.m

matlab -nojvm -nodisplay -nosplash -r 'tree_796'
rm 796.train_all.dat
rm 796.test_all.dat
rm tree_796.m

matlab -nojvm -nodisplay -nosplash -r 'tree_797'
rm 797.train_all.dat
rm 797.test_all.dat
rm tree_797.m

matlab -nojvm -nodisplay -nosplash -r 'tree_798'
rm 798.train_all.dat
rm 798.test_all.dat
rm tree_798.m

matlab -nojvm -nodisplay -nosplash -r 'tree_799'
rm 799.train_all.dat
rm 799.test_all.dat
rm tree_799.m

matlab -nojvm -nodisplay -nosplash -r 'tree_800'
rm 800.train_all.dat
rm 800.test_all.dat
rm tree_800.m

matlab -nojvm -nodisplay -nosplash -r 'tree_801'
rm 801.train_all.dat
rm 801.test_all.dat
rm tree_801.m

matlab -nojvm -nodisplay -nosplash -r 'tree_802'
rm 802.train_all.dat
rm 802.test_all.dat
rm tree_802.m

matlab -nojvm -nodisplay -nosplash -r 'tree_803'
rm 803.train_all.dat
rm 803.test_all.dat
rm tree_803.m

matlab -nojvm -nodisplay -nosplash -r 'tree_804'
rm 804.train_all.dat
rm 804.test_all.dat
rm tree_804.m

matlab -nojvm -nodisplay -nosplash -r 'tree_805'
rm 805.train_all.dat
rm 805.test_all.dat
rm tree_805.m

matlab -nojvm -nodisplay -nosplash -r 'tree_806'
rm 806.train_all.dat
rm 806.test_all.dat
rm tree_806.m

matlab -nojvm -nodisplay -nosplash -r 'tree_807'
rm 807.train_all.dat
rm 807.test_all.dat
rm tree_807.m

matlab -nojvm -nodisplay -nosplash -r 'tree_808'
rm 808.train_all.dat
rm 808.test_all.dat
rm tree_808.m

matlab -nojvm -nodisplay -nosplash -r 'tree_809'
rm 809.train_all.dat
rm 809.test_all.dat
rm tree_809.m

matlab -nojvm -nodisplay -nosplash -r 'tree_810'
rm 810.train_all.dat
rm 810.test_all.dat
rm tree_810.m

matlab -nojvm -nodisplay -nosplash -r 'tree_811'
rm 811.train_all.dat
rm 811.test_all.dat
rm tree_811.m

matlab -nojvm -nodisplay -nosplash -r 'tree_812'
rm 812.train_all.dat
rm 812.test_all.dat
rm tree_812.m

matlab -nojvm -nodisplay -nosplash -r 'tree_813'
rm 813.train_all.dat
rm 813.test_all.dat
rm tree_813.m

matlab -nojvm -nodisplay -nosplash -r 'tree_814'
rm 814.train_all.dat
rm 814.test_all.dat
rm tree_814.m

matlab -nojvm -nodisplay -nosplash -r 'tree_815'
rm 815.train_all.dat
rm 815.test_all.dat
rm tree_815.m

matlab -nojvm -nodisplay -nosplash -r 'tree_816'
rm 816.train_all.dat
rm 816.test_all.dat
rm tree_816.m

matlab -nojvm -nodisplay -nosplash -r 'tree_817'
rm 817.train_all.dat
rm 817.test_all.dat
rm tree_817.m

matlab -nojvm -nodisplay -nosplash -r 'tree_818'
rm 818.train_all.dat
rm 818.test_all.dat
rm tree_818.m

matlab -nojvm -nodisplay -nosplash -r 'tree_819'
rm 819.train_all.dat
rm 819.test_all.dat
rm tree_819.m

matlab -nojvm -nodisplay -nosplash -r 'tree_820'
rm 820.train_all.dat
rm 820.test_all.dat
rm tree_820.m

matlab -nojvm -nodisplay -nosplash -r 'tree_821'
rm 821.train_all.dat
rm 821.test_all.dat
rm tree_821.m

matlab -nojvm -nodisplay -nosplash -r 'tree_822'
rm 822.train_all.dat
rm 822.test_all.dat
rm tree_822.m

matlab -nojvm -nodisplay -nosplash -r 'tree_823'
rm 823.train_all.dat
rm 823.test_all.dat
rm tree_823.m

matlab -nojvm -nodisplay -nosplash -r 'tree_824'
rm 824.train_all.dat
rm 824.test_all.dat
rm tree_824.m

matlab -nojvm -nodisplay -nosplash -r 'tree_825'
rm 825.train_all.dat
rm 825.test_all.dat
rm tree_825.m

matlab -nojvm -nodisplay -nosplash -r 'tree_826'
rm 826.train_all.dat
rm 826.test_all.dat
rm tree_826.m

matlab -nojvm -nodisplay -nosplash -r 'tree_827'
rm 827.train_all.dat
rm 827.test_all.dat
rm tree_827.m

matlab -nojvm -nodisplay -nosplash -r 'tree_828'
rm 828.train_all.dat
rm 828.test_all.dat
rm tree_828.m

matlab -nojvm -nodisplay -nosplash -r 'tree_829'
rm 829.train_all.dat
rm 829.test_all.dat
rm tree_829.m

matlab -nojvm -nodisplay -nosplash -r 'tree_830'
rm 830.train_all.dat
rm 830.test_all.dat
rm tree_830.m

matlab -nojvm -nodisplay -nosplash -r 'tree_831'
rm 831.train_all.dat
rm 831.test_all.dat
rm tree_831.m

matlab -nojvm -nodisplay -nosplash -r 'tree_832'
rm 832.train_all.dat
rm 832.test_all.dat
rm tree_832.m

matlab -nojvm -nodisplay -nosplash -r 'tree_833'
rm 833.train_all.dat
rm 833.test_all.dat
rm tree_833.m

