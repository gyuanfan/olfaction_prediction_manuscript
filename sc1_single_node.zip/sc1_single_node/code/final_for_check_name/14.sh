matlab -nojvm -nodisplay -nosplash -r 'tree_638'
rm 638.train_all.dat
rm 638.test_all.dat
rm tree_638.m

matlab -nojvm -nodisplay -nosplash -r 'tree_639'
rm 639.train_all.dat
rm 639.test_all.dat
rm tree_639.m

matlab -nojvm -nodisplay -nosplash -r 'tree_640'
rm 640.train_all.dat
rm 640.test_all.dat
rm tree_640.m

matlab -nojvm -nodisplay -nosplash -r 'tree_641'
rm 641.train_all.dat
rm 641.test_all.dat
rm tree_641.m

matlab -nojvm -nodisplay -nosplash -r 'tree_642'
rm 642.train_all.dat
rm 642.test_all.dat
rm tree_642.m

matlab -nojvm -nodisplay -nosplash -r 'tree_643'
rm 643.train_all.dat
rm 643.test_all.dat
rm tree_643.m

matlab -nojvm -nodisplay -nosplash -r 'tree_644'
rm 644.train_all.dat
rm 644.test_all.dat
rm tree_644.m

matlab -nojvm -nodisplay -nosplash -r 'tree_645'
rm 645.train_all.dat
rm 645.test_all.dat
rm tree_645.m

matlab -nojvm -nodisplay -nosplash -r 'tree_646'
rm 646.train_all.dat
rm 646.test_all.dat
rm tree_646.m

matlab -nojvm -nodisplay -nosplash -r 'tree_647'
rm 647.train_all.dat
rm 647.test_all.dat
rm tree_647.m

matlab -nojvm -nodisplay -nosplash -r 'tree_648'
rm 648.train_all.dat
rm 648.test_all.dat
rm tree_648.m

matlab -nojvm -nodisplay -nosplash -r 'tree_649'
rm 649.train_all.dat
rm 649.test_all.dat
rm tree_649.m

matlab -nojvm -nodisplay -nosplash -r 'tree_650'
rm 650.train_all.dat
rm 650.test_all.dat
rm tree_650.m

matlab -nojvm -nodisplay -nosplash -r 'tree_651'
rm 651.train_all.dat
rm 651.test_all.dat
rm tree_651.m

matlab -nojvm -nodisplay -nosplash -r 'tree_652'
rm 652.train_all.dat
rm 652.test_all.dat
rm tree_652.m

matlab -nojvm -nodisplay -nosplash -r 'tree_653'
rm 653.train_all.dat
rm 653.test_all.dat
rm tree_653.m

matlab -nojvm -nodisplay -nosplash -r 'tree_654'
rm 654.train_all.dat
rm 654.test_all.dat
rm tree_654.m

matlab -nojvm -nodisplay -nosplash -r 'tree_655'
rm 655.train_all.dat
rm 655.test_all.dat
rm tree_655.m

matlab -nojvm -nodisplay -nosplash -r 'tree_656'
rm 656.train_all.dat
rm 656.test_all.dat
rm tree_656.m

matlab -nojvm -nodisplay -nosplash -r 'tree_657'
rm 657.train_all.dat
rm 657.test_all.dat
rm tree_657.m

matlab -nojvm -nodisplay -nosplash -r 'tree_658'
rm 658.train_all.dat
rm 658.test_all.dat
rm tree_658.m

matlab -nojvm -nodisplay -nosplash -r 'tree_659'
rm 659.train_all.dat
rm 659.test_all.dat
rm tree_659.m

matlab -nojvm -nodisplay -nosplash -r 'tree_660'
rm 660.train_all.dat
rm 660.test_all.dat
rm tree_660.m

matlab -nojvm -nodisplay -nosplash -r 'tree_661'
rm 661.train_all.dat
rm 661.test_all.dat
rm tree_661.m

matlab -nojvm -nodisplay -nosplash -r 'tree_662'
rm 662.train_all.dat
rm 662.test_all.dat
rm tree_662.m

matlab -nojvm -nodisplay -nosplash -r 'tree_663'
rm 663.train_all.dat
rm 663.test_all.dat
rm tree_663.m

matlab -nojvm -nodisplay -nosplash -r 'tree_664'
rm 664.train_all.dat
rm 664.test_all.dat
rm tree_664.m

matlab -nojvm -nodisplay -nosplash -r 'tree_665'
rm 665.train_all.dat
rm 665.test_all.dat
rm tree_665.m

matlab -nojvm -nodisplay -nosplash -r 'tree_666'
rm 666.train_all.dat
rm 666.test_all.dat
rm tree_666.m

matlab -nojvm -nodisplay -nosplash -r 'tree_667'
rm 667.train_all.dat
rm 667.test_all.dat
rm tree_667.m

matlab -nojvm -nodisplay -nosplash -r 'tree_668'
rm 668.train_all.dat
rm 668.test_all.dat
rm tree_668.m

matlab -nojvm -nodisplay -nosplash -r 'tree_669'
rm 669.train_all.dat
rm 669.test_all.dat
rm tree_669.m

matlab -nojvm -nodisplay -nosplash -r 'tree_670'
rm 670.train_all.dat
rm 670.test_all.dat
rm tree_670.m

matlab -nojvm -nodisplay -nosplash -r 'tree_671'
rm 671.train_all.dat
rm 671.test_all.dat
rm tree_671.m

matlab -nojvm -nodisplay -nosplash -r 'tree_672'
rm 672.train_all.dat
rm 672.test_all.dat
rm tree_672.m

matlab -nojvm -nodisplay -nosplash -r 'tree_673'
rm 673.train_all.dat
rm 673.test_all.dat
rm tree_673.m

matlab -nojvm -nodisplay -nosplash -r 'tree_674'
rm 674.train_all.dat
rm 674.test_all.dat
rm tree_674.m

matlab -nojvm -nodisplay -nosplash -r 'tree_675'
rm 675.train_all.dat
rm 675.test_all.dat
rm tree_675.m

matlab -nojvm -nodisplay -nosplash -r 'tree_676'
rm 676.train_all.dat
rm 676.test_all.dat
rm tree_676.m

matlab -nojvm -nodisplay -nosplash -r 'tree_677'
rm 677.train_all.dat
rm 677.test_all.dat
rm tree_677.m

matlab -nojvm -nodisplay -nosplash -r 'tree_678'
rm 678.train_all.dat
rm 678.test_all.dat
rm tree_678.m

matlab -nojvm -nodisplay -nosplash -r 'tree_679'
rm 679.train_all.dat
rm 679.test_all.dat
rm tree_679.m

matlab -nojvm -nodisplay -nosplash -r 'tree_680'
rm 680.train_all.dat
rm 680.test_all.dat
rm tree_680.m

matlab -nojvm -nodisplay -nosplash -r 'tree_681'
rm 681.train_all.dat
rm 681.test_all.dat
rm tree_681.m

matlab -nojvm -nodisplay -nosplash -r 'tree_682'
rm 682.train_all.dat
rm 682.test_all.dat
rm tree_682.m

matlab -nojvm -nodisplay -nosplash -r 'tree_683'
rm 683.train_all.dat
rm 683.test_all.dat
rm tree_683.m

matlab -nojvm -nodisplay -nosplash -r 'tree_684'
rm 684.train_all.dat
rm 684.test_all.dat
rm tree_684.m

matlab -nojvm -nodisplay -nosplash -r 'tree_685'
rm 685.train_all.dat
rm 685.test_all.dat
rm tree_685.m

matlab -nojvm -nodisplay -nosplash -r 'tree_686'
rm 686.train_all.dat
rm 686.test_all.dat
rm tree_686.m

