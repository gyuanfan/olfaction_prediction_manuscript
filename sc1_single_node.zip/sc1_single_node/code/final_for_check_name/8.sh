matlab -nojvm -nodisplay -nosplash -r 'tree_344'
rm 344.train_all.dat
rm 344.test_all.dat
rm tree_344.m

matlab -nojvm -nodisplay -nosplash -r 'tree_345'
rm 345.train_all.dat
rm 345.test_all.dat
rm tree_345.m

matlab -nojvm -nodisplay -nosplash -r 'tree_346'
rm 346.train_all.dat
rm 346.test_all.dat
rm tree_346.m

matlab -nojvm -nodisplay -nosplash -r 'tree_347'
rm 347.train_all.dat
rm 347.test_all.dat
rm tree_347.m

matlab -nojvm -nodisplay -nosplash -r 'tree_348'
rm 348.train_all.dat
rm 348.test_all.dat
rm tree_348.m

matlab -nojvm -nodisplay -nosplash -r 'tree_349'
rm 349.train_all.dat
rm 349.test_all.dat
rm tree_349.m

matlab -nojvm -nodisplay -nosplash -r 'tree_350'
rm 350.train_all.dat
rm 350.test_all.dat
rm tree_350.m

matlab -nojvm -nodisplay -nosplash -r 'tree_351'
rm 351.train_all.dat
rm 351.test_all.dat
rm tree_351.m

matlab -nojvm -nodisplay -nosplash -r 'tree_352'
rm 352.train_all.dat
rm 352.test_all.dat
rm tree_352.m

matlab -nojvm -nodisplay -nosplash -r 'tree_353'
rm 353.train_all.dat
rm 353.test_all.dat
rm tree_353.m

matlab -nojvm -nodisplay -nosplash -r 'tree_354'
rm 354.train_all.dat
rm 354.test_all.dat
rm tree_354.m

matlab -nojvm -nodisplay -nosplash -r 'tree_355'
rm 355.train_all.dat
rm 355.test_all.dat
rm tree_355.m

matlab -nojvm -nodisplay -nosplash -r 'tree_356'
rm 356.train_all.dat
rm 356.test_all.dat
rm tree_356.m

matlab -nojvm -nodisplay -nosplash -r 'tree_357'
rm 357.train_all.dat
rm 357.test_all.dat
rm tree_357.m

matlab -nojvm -nodisplay -nosplash -r 'tree_358'
rm 358.train_all.dat
rm 358.test_all.dat
rm tree_358.m

matlab -nojvm -nodisplay -nosplash -r 'tree_359'
rm 359.train_all.dat
rm 359.test_all.dat
rm tree_359.m

matlab -nojvm -nodisplay -nosplash -r 'tree_360'
rm 360.train_all.dat
rm 360.test_all.dat
rm tree_360.m

matlab -nojvm -nodisplay -nosplash -r 'tree_361'
rm 361.train_all.dat
rm 361.test_all.dat
rm tree_361.m

matlab -nojvm -nodisplay -nosplash -r 'tree_362'
rm 362.train_all.dat
rm 362.test_all.dat
rm tree_362.m

matlab -nojvm -nodisplay -nosplash -r 'tree_363'
rm 363.train_all.dat
rm 363.test_all.dat
rm tree_363.m

matlab -nojvm -nodisplay -nosplash -r 'tree_364'
rm 364.train_all.dat
rm 364.test_all.dat
rm tree_364.m

matlab -nojvm -nodisplay -nosplash -r 'tree_365'
rm 365.train_all.dat
rm 365.test_all.dat
rm tree_365.m

matlab -nojvm -nodisplay -nosplash -r 'tree_366'
rm 366.train_all.dat
rm 366.test_all.dat
rm tree_366.m

matlab -nojvm -nodisplay -nosplash -r 'tree_367'
rm 367.train_all.dat
rm 367.test_all.dat
rm tree_367.m

matlab -nojvm -nodisplay -nosplash -r 'tree_368'
rm 368.train_all.dat
rm 368.test_all.dat
rm tree_368.m

matlab -nojvm -nodisplay -nosplash -r 'tree_369'
rm 369.train_all.dat
rm 369.test_all.dat
rm tree_369.m

matlab -nojvm -nodisplay -nosplash -r 'tree_370'
rm 370.train_all.dat
rm 370.test_all.dat
rm tree_370.m

matlab -nojvm -nodisplay -nosplash -r 'tree_371'
rm 371.train_all.dat
rm 371.test_all.dat
rm tree_371.m

matlab -nojvm -nodisplay -nosplash -r 'tree_372'
rm 372.train_all.dat
rm 372.test_all.dat
rm tree_372.m

matlab -nojvm -nodisplay -nosplash -r 'tree_373'
rm 373.train_all.dat
rm 373.test_all.dat
rm tree_373.m

matlab -nojvm -nodisplay -nosplash -r 'tree_374'
rm 374.train_all.dat
rm 374.test_all.dat
rm tree_374.m

matlab -nojvm -nodisplay -nosplash -r 'tree_375'
rm 375.train_all.dat
rm 375.test_all.dat
rm tree_375.m

matlab -nojvm -nodisplay -nosplash -r 'tree_376'
rm 376.train_all.dat
rm 376.test_all.dat
rm tree_376.m

matlab -nojvm -nodisplay -nosplash -r 'tree_377'
rm 377.train_all.dat
rm 377.test_all.dat
rm tree_377.m

matlab -nojvm -nodisplay -nosplash -r 'tree_378'
rm 378.train_all.dat
rm 378.test_all.dat
rm tree_378.m

matlab -nojvm -nodisplay -nosplash -r 'tree_379'
rm 379.train_all.dat
rm 379.test_all.dat
rm tree_379.m

matlab -nojvm -nodisplay -nosplash -r 'tree_380'
rm 380.train_all.dat
rm 380.test_all.dat
rm tree_380.m

matlab -nojvm -nodisplay -nosplash -r 'tree_381'
rm 381.train_all.dat
rm 381.test_all.dat
rm tree_381.m

matlab -nojvm -nodisplay -nosplash -r 'tree_382'
rm 382.train_all.dat
rm 382.test_all.dat
rm tree_382.m

matlab -nojvm -nodisplay -nosplash -r 'tree_383'
rm 383.train_all.dat
rm 383.test_all.dat
rm tree_383.m

matlab -nojvm -nodisplay -nosplash -r 'tree_384'
rm 384.train_all.dat
rm 384.test_all.dat
rm tree_384.m

matlab -nojvm -nodisplay -nosplash -r 'tree_385'
rm 385.train_all.dat
rm 385.test_all.dat
rm tree_385.m

matlab -nojvm -nodisplay -nosplash -r 'tree_386'
rm 386.train_all.dat
rm 386.test_all.dat
rm tree_386.m

matlab -nojvm -nodisplay -nosplash -r 'tree_387'
rm 387.train_all.dat
rm 387.test_all.dat
rm tree_387.m

matlab -nojvm -nodisplay -nosplash -r 'tree_388'
rm 388.train_all.dat
rm 388.test_all.dat
rm tree_388.m

matlab -nojvm -nodisplay -nosplash -r 'tree_389'
rm 389.train_all.dat
rm 389.test_all.dat
rm tree_389.m

matlab -nojvm -nodisplay -nosplash -r 'tree_390'
rm 390.train_all.dat
rm 390.test_all.dat
rm tree_390.m

matlab -nojvm -nodisplay -nosplash -r 'tree_391'
rm 391.train_all.dat
rm 391.test_all.dat
rm tree_391.m

matlab -nojvm -nodisplay -nosplash -r 'tree_392'
rm 392.train_all.dat
rm 392.test_all.dat
rm tree_392.m

