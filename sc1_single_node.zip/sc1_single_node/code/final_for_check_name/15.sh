matlab -nojvm -nodisplay -nosplash -r 'tree_687'
rm 687.train_all.dat
rm 687.test_all.dat
rm tree_687.m

matlab -nojvm -nodisplay -nosplash -r 'tree_688'
rm 688.train_all.dat
rm 688.test_all.dat
rm tree_688.m

matlab -nojvm -nodisplay -nosplash -r 'tree_689'
rm 689.train_all.dat
rm 689.test_all.dat
rm tree_689.m

matlab -nojvm -nodisplay -nosplash -r 'tree_690'
rm 690.train_all.dat
rm 690.test_all.dat
rm tree_690.m

matlab -nojvm -nodisplay -nosplash -r 'tree_691'
rm 691.train_all.dat
rm 691.test_all.dat
rm tree_691.m

matlab -nojvm -nodisplay -nosplash -r 'tree_692'
rm 692.train_all.dat
rm 692.test_all.dat
rm tree_692.m

matlab -nojvm -nodisplay -nosplash -r 'tree_693'
rm 693.train_all.dat
rm 693.test_all.dat
rm tree_693.m

matlab -nojvm -nodisplay -nosplash -r 'tree_694'
rm 694.train_all.dat
rm 694.test_all.dat
rm tree_694.m

matlab -nojvm -nodisplay -nosplash -r 'tree_695'
rm 695.train_all.dat
rm 695.test_all.dat
rm tree_695.m

matlab -nojvm -nodisplay -nosplash -r 'tree_696'
rm 696.train_all.dat
rm 696.test_all.dat
rm tree_696.m

matlab -nojvm -nodisplay -nosplash -r 'tree_697'
rm 697.train_all.dat
rm 697.test_all.dat
rm tree_697.m

matlab -nojvm -nodisplay -nosplash -r 'tree_698'
rm 698.train_all.dat
rm 698.test_all.dat
rm tree_698.m

matlab -nojvm -nodisplay -nosplash -r 'tree_699'
rm 699.train_all.dat
rm 699.test_all.dat
rm tree_699.m

matlab -nojvm -nodisplay -nosplash -r 'tree_700'
rm 700.train_all.dat
rm 700.test_all.dat
rm tree_700.m

matlab -nojvm -nodisplay -nosplash -r 'tree_701'
rm 701.train_all.dat
rm 701.test_all.dat
rm tree_701.m

matlab -nojvm -nodisplay -nosplash -r 'tree_702'
rm 702.train_all.dat
rm 702.test_all.dat
rm tree_702.m

matlab -nojvm -nodisplay -nosplash -r 'tree_703'
rm 703.train_all.dat
rm 703.test_all.dat
rm tree_703.m

matlab -nojvm -nodisplay -nosplash -r 'tree_704'
rm 704.train_all.dat
rm 704.test_all.dat
rm tree_704.m

matlab -nojvm -nodisplay -nosplash -r 'tree_705'
rm 705.train_all.dat
rm 705.test_all.dat
rm tree_705.m

matlab -nojvm -nodisplay -nosplash -r 'tree_706'
rm 706.train_all.dat
rm 706.test_all.dat
rm tree_706.m

matlab -nojvm -nodisplay -nosplash -r 'tree_707'
rm 707.train_all.dat
rm 707.test_all.dat
rm tree_707.m

matlab -nojvm -nodisplay -nosplash -r 'tree_708'
rm 708.train_all.dat
rm 708.test_all.dat
rm tree_708.m

matlab -nojvm -nodisplay -nosplash -r 'tree_709'
rm 709.train_all.dat
rm 709.test_all.dat
rm tree_709.m

matlab -nojvm -nodisplay -nosplash -r 'tree_710'
rm 710.train_all.dat
rm 710.test_all.dat
rm tree_710.m

matlab -nojvm -nodisplay -nosplash -r 'tree_711'
rm 711.train_all.dat
rm 711.test_all.dat
rm tree_711.m

matlab -nojvm -nodisplay -nosplash -r 'tree_712'
rm 712.train_all.dat
rm 712.test_all.dat
rm tree_712.m

matlab -nojvm -nodisplay -nosplash -r 'tree_713'
rm 713.train_all.dat
rm 713.test_all.dat
rm tree_713.m

matlab -nojvm -nodisplay -nosplash -r 'tree_714'
rm 714.train_all.dat
rm 714.test_all.dat
rm tree_714.m

matlab -nojvm -nodisplay -nosplash -r 'tree_715'
rm 715.train_all.dat
rm 715.test_all.dat
rm tree_715.m

matlab -nojvm -nodisplay -nosplash -r 'tree_716'
rm 716.train_all.dat
rm 716.test_all.dat
rm tree_716.m

matlab -nojvm -nodisplay -nosplash -r 'tree_717'
rm 717.train_all.dat
rm 717.test_all.dat
rm tree_717.m

matlab -nojvm -nodisplay -nosplash -r 'tree_718'
rm 718.train_all.dat
rm 718.test_all.dat
rm tree_718.m

matlab -nojvm -nodisplay -nosplash -r 'tree_719'
rm 719.train_all.dat
rm 719.test_all.dat
rm tree_719.m

matlab -nojvm -nodisplay -nosplash -r 'tree_720'
rm 720.train_all.dat
rm 720.test_all.dat
rm tree_720.m

matlab -nojvm -nodisplay -nosplash -r 'tree_721'
rm 721.train_all.dat
rm 721.test_all.dat
rm tree_721.m

matlab -nojvm -nodisplay -nosplash -r 'tree_722'
rm 722.train_all.dat
rm 722.test_all.dat
rm tree_722.m

matlab -nojvm -nodisplay -nosplash -r 'tree_723'
rm 723.train_all.dat
rm 723.test_all.dat
rm tree_723.m

matlab -nojvm -nodisplay -nosplash -r 'tree_724'
rm 724.train_all.dat
rm 724.test_all.dat
rm tree_724.m

matlab -nojvm -nodisplay -nosplash -r 'tree_725'
rm 725.train_all.dat
rm 725.test_all.dat
rm tree_725.m

matlab -nojvm -nodisplay -nosplash -r 'tree_726'
rm 726.train_all.dat
rm 726.test_all.dat
rm tree_726.m

matlab -nojvm -nodisplay -nosplash -r 'tree_727'
rm 727.train_all.dat
rm 727.test_all.dat
rm tree_727.m

matlab -nojvm -nodisplay -nosplash -r 'tree_728'
rm 728.train_all.dat
rm 728.test_all.dat
rm tree_728.m

matlab -nojvm -nodisplay -nosplash -r 'tree_729'
rm 729.train_all.dat
rm 729.test_all.dat
rm tree_729.m

matlab -nojvm -nodisplay -nosplash -r 'tree_730'
rm 730.train_all.dat
rm 730.test_all.dat
rm tree_730.m

matlab -nojvm -nodisplay -nosplash -r 'tree_731'
rm 731.train_all.dat
rm 731.test_all.dat
rm tree_731.m

matlab -nojvm -nodisplay -nosplash -r 'tree_732'
rm 732.train_all.dat
rm 732.test_all.dat
rm tree_732.m

matlab -nojvm -nodisplay -nosplash -r 'tree_733'
rm 733.train_all.dat
rm 733.test_all.dat
rm tree_733.m

matlab -nojvm -nodisplay -nosplash -r 'tree_734'
rm 734.train_all.dat
rm 734.test_all.dat
rm tree_734.m

matlab -nojvm -nodisplay -nosplash -r 'tree_735'
rm 735.train_all.dat
rm 735.test_all.dat
rm tree_735.m

