matlab -nojvm -nodisplay -nosplash -r 'tree_246'
rm 246.train_all.dat
rm 246.test_all.dat
rm tree_246.m

matlab -nojvm -nodisplay -nosplash -r 'tree_247'
rm 247.train_all.dat
rm 247.test_all.dat
rm tree_247.m

matlab -nojvm -nodisplay -nosplash -r 'tree_248'
rm 248.train_all.dat
rm 248.test_all.dat
rm tree_248.m

matlab -nojvm -nodisplay -nosplash -r 'tree_249'
rm 249.train_all.dat
rm 249.test_all.dat
rm tree_249.m

matlab -nojvm -nodisplay -nosplash -r 'tree_250'
rm 250.train_all.dat
rm 250.test_all.dat
rm tree_250.m

matlab -nojvm -nodisplay -nosplash -r 'tree_251'
rm 251.train_all.dat
rm 251.test_all.dat
rm tree_251.m

matlab -nojvm -nodisplay -nosplash -r 'tree_252'
rm 252.train_all.dat
rm 252.test_all.dat
rm tree_252.m

matlab -nojvm -nodisplay -nosplash -r 'tree_253'
rm 253.train_all.dat
rm 253.test_all.dat
rm tree_253.m

matlab -nojvm -nodisplay -nosplash -r 'tree_254'
rm 254.train_all.dat
rm 254.test_all.dat
rm tree_254.m

matlab -nojvm -nodisplay -nosplash -r 'tree_255'
rm 255.train_all.dat
rm 255.test_all.dat
rm tree_255.m

matlab -nojvm -nodisplay -nosplash -r 'tree_256'
rm 256.train_all.dat
rm 256.test_all.dat
rm tree_256.m

matlab -nojvm -nodisplay -nosplash -r 'tree_257'
rm 257.train_all.dat
rm 257.test_all.dat
rm tree_257.m

matlab -nojvm -nodisplay -nosplash -r 'tree_258'
rm 258.train_all.dat
rm 258.test_all.dat
rm tree_258.m

matlab -nojvm -nodisplay -nosplash -r 'tree_259'
rm 259.train_all.dat
rm 259.test_all.dat
rm tree_259.m

matlab -nojvm -nodisplay -nosplash -r 'tree_260'
rm 260.train_all.dat
rm 260.test_all.dat
rm tree_260.m

matlab -nojvm -nodisplay -nosplash -r 'tree_261'
rm 261.train_all.dat
rm 261.test_all.dat
rm tree_261.m

matlab -nojvm -nodisplay -nosplash -r 'tree_262'
rm 262.train_all.dat
rm 262.test_all.dat
rm tree_262.m

matlab -nojvm -nodisplay -nosplash -r 'tree_263'
rm 263.train_all.dat
rm 263.test_all.dat
rm tree_263.m

matlab -nojvm -nodisplay -nosplash -r 'tree_264'
rm 264.train_all.dat
rm 264.test_all.dat
rm tree_264.m

matlab -nojvm -nodisplay -nosplash -r 'tree_265'
rm 265.train_all.dat
rm 265.test_all.dat
rm tree_265.m

matlab -nojvm -nodisplay -nosplash -r 'tree_266'
rm 266.train_all.dat
rm 266.test_all.dat
rm tree_266.m

matlab -nojvm -nodisplay -nosplash -r 'tree_267'
rm 267.train_all.dat
rm 267.test_all.dat
rm tree_267.m

matlab -nojvm -nodisplay -nosplash -r 'tree_268'
rm 268.train_all.dat
rm 268.test_all.dat
rm tree_268.m

matlab -nojvm -nodisplay -nosplash -r 'tree_269'
rm 269.train_all.dat
rm 269.test_all.dat
rm tree_269.m

matlab -nojvm -nodisplay -nosplash -r 'tree_270'
rm 270.train_all.dat
rm 270.test_all.dat
rm tree_270.m

matlab -nojvm -nodisplay -nosplash -r 'tree_271'
rm 271.train_all.dat
rm 271.test_all.dat
rm tree_271.m

matlab -nojvm -nodisplay -nosplash -r 'tree_272'
rm 272.train_all.dat
rm 272.test_all.dat
rm tree_272.m

matlab -nojvm -nodisplay -nosplash -r 'tree_273'
rm 273.train_all.dat
rm 273.test_all.dat
rm tree_273.m

matlab -nojvm -nodisplay -nosplash -r 'tree_274'
rm 274.train_all.dat
rm 274.test_all.dat
rm tree_274.m

matlab -nojvm -nodisplay -nosplash -r 'tree_275'
rm 275.train_all.dat
rm 275.test_all.dat
rm tree_275.m

matlab -nojvm -nodisplay -nosplash -r 'tree_276'
rm 276.train_all.dat
rm 276.test_all.dat
rm tree_276.m

matlab -nojvm -nodisplay -nosplash -r 'tree_277'
rm 277.train_all.dat
rm 277.test_all.dat
rm tree_277.m

matlab -nojvm -nodisplay -nosplash -r 'tree_278'
rm 278.train_all.dat
rm 278.test_all.dat
rm tree_278.m

matlab -nojvm -nodisplay -nosplash -r 'tree_279'
rm 279.train_all.dat
rm 279.test_all.dat
rm tree_279.m

matlab -nojvm -nodisplay -nosplash -r 'tree_280'
rm 280.train_all.dat
rm 280.test_all.dat
rm tree_280.m

matlab -nojvm -nodisplay -nosplash -r 'tree_281'
rm 281.train_all.dat
rm 281.test_all.dat
rm tree_281.m

matlab -nojvm -nodisplay -nosplash -r 'tree_282'
rm 282.train_all.dat
rm 282.test_all.dat
rm tree_282.m

matlab -nojvm -nodisplay -nosplash -r 'tree_283'
rm 283.train_all.dat
rm 283.test_all.dat
rm tree_283.m

matlab -nojvm -nodisplay -nosplash -r 'tree_284'
rm 284.train_all.dat
rm 284.test_all.dat
rm tree_284.m

matlab -nojvm -nodisplay -nosplash -r 'tree_285'
rm 285.train_all.dat
rm 285.test_all.dat
rm tree_285.m

matlab -nojvm -nodisplay -nosplash -r 'tree_286'
rm 286.train_all.dat
rm 286.test_all.dat
rm tree_286.m

matlab -nojvm -nodisplay -nosplash -r 'tree_287'
rm 287.train_all.dat
rm 287.test_all.dat
rm tree_287.m

matlab -nojvm -nodisplay -nosplash -r 'tree_288'
rm 288.train_all.dat
rm 288.test_all.dat
rm tree_288.m

matlab -nojvm -nodisplay -nosplash -r 'tree_289'
rm 289.train_all.dat
rm 289.test_all.dat
rm tree_289.m

matlab -nojvm -nodisplay -nosplash -r 'tree_290'
rm 290.train_all.dat
rm 290.test_all.dat
rm tree_290.m

matlab -nojvm -nodisplay -nosplash -r 'tree_291'
rm 291.train_all.dat
rm 291.test_all.dat
rm tree_291.m

matlab -nojvm -nodisplay -nosplash -r 'tree_292'
rm 292.train_all.dat
rm 292.test_all.dat
rm tree_292.m

matlab -nojvm -nodisplay -nosplash -r 'tree_293'
rm 293.train_all.dat
rm 293.test_all.dat
rm tree_293.m

matlab -nojvm -nodisplay -nosplash -r 'tree_294'
rm 294.train_all.dat
rm 294.test_all.dat
rm tree_294.m

