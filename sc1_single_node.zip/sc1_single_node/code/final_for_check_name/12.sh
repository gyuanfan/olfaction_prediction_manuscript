matlab -nojvm -nodisplay -nosplash -r 'tree_540'
rm 540.train_all.dat
rm 540.test_all.dat
rm tree_540.m

matlab -nojvm -nodisplay -nosplash -r 'tree_541'
rm 541.train_all.dat
rm 541.test_all.dat
rm tree_541.m

matlab -nojvm -nodisplay -nosplash -r 'tree_542'
rm 542.train_all.dat
rm 542.test_all.dat
rm tree_542.m

matlab -nojvm -nodisplay -nosplash -r 'tree_543'
rm 543.train_all.dat
rm 543.test_all.dat
rm tree_543.m

matlab -nojvm -nodisplay -nosplash -r 'tree_544'
rm 544.train_all.dat
rm 544.test_all.dat
rm tree_544.m

matlab -nojvm -nodisplay -nosplash -r 'tree_545'
rm 545.train_all.dat
rm 545.test_all.dat
rm tree_545.m

matlab -nojvm -nodisplay -nosplash -r 'tree_546'
rm 546.train_all.dat
rm 546.test_all.dat
rm tree_546.m

matlab -nojvm -nodisplay -nosplash -r 'tree_547'
rm 547.train_all.dat
rm 547.test_all.dat
rm tree_547.m

matlab -nojvm -nodisplay -nosplash -r 'tree_548'
rm 548.train_all.dat
rm 548.test_all.dat
rm tree_548.m

matlab -nojvm -nodisplay -nosplash -r 'tree_549'
rm 549.train_all.dat
rm 549.test_all.dat
rm tree_549.m

matlab -nojvm -nodisplay -nosplash -r 'tree_550'
rm 550.train_all.dat
rm 550.test_all.dat
rm tree_550.m

matlab -nojvm -nodisplay -nosplash -r 'tree_551'
rm 551.train_all.dat
rm 551.test_all.dat
rm tree_551.m

matlab -nojvm -nodisplay -nosplash -r 'tree_552'
rm 552.train_all.dat
rm 552.test_all.dat
rm tree_552.m

matlab -nojvm -nodisplay -nosplash -r 'tree_553'
rm 553.train_all.dat
rm 553.test_all.dat
rm tree_553.m

matlab -nojvm -nodisplay -nosplash -r 'tree_554'
rm 554.train_all.dat
rm 554.test_all.dat
rm tree_554.m

matlab -nojvm -nodisplay -nosplash -r 'tree_555'
rm 555.train_all.dat
rm 555.test_all.dat
rm tree_555.m

matlab -nojvm -nodisplay -nosplash -r 'tree_556'
rm 556.train_all.dat
rm 556.test_all.dat
rm tree_556.m

matlab -nojvm -nodisplay -nosplash -r 'tree_557'
rm 557.train_all.dat
rm 557.test_all.dat
rm tree_557.m

matlab -nojvm -nodisplay -nosplash -r 'tree_558'
rm 558.train_all.dat
rm 558.test_all.dat
rm tree_558.m

matlab -nojvm -nodisplay -nosplash -r 'tree_559'
rm 559.train_all.dat
rm 559.test_all.dat
rm tree_559.m

matlab -nojvm -nodisplay -nosplash -r 'tree_560'
rm 560.train_all.dat
rm 560.test_all.dat
rm tree_560.m

matlab -nojvm -nodisplay -nosplash -r 'tree_561'
rm 561.train_all.dat
rm 561.test_all.dat
rm tree_561.m

matlab -nojvm -nodisplay -nosplash -r 'tree_562'
rm 562.train_all.dat
rm 562.test_all.dat
rm tree_562.m

matlab -nojvm -nodisplay -nosplash -r 'tree_563'
rm 563.train_all.dat
rm 563.test_all.dat
rm tree_563.m

matlab -nojvm -nodisplay -nosplash -r 'tree_564'
rm 564.train_all.dat
rm 564.test_all.dat
rm tree_564.m

matlab -nojvm -nodisplay -nosplash -r 'tree_565'
rm 565.train_all.dat
rm 565.test_all.dat
rm tree_565.m

matlab -nojvm -nodisplay -nosplash -r 'tree_566'
rm 566.train_all.dat
rm 566.test_all.dat
rm tree_566.m

matlab -nojvm -nodisplay -nosplash -r 'tree_567'
rm 567.train_all.dat
rm 567.test_all.dat
rm tree_567.m

matlab -nojvm -nodisplay -nosplash -r 'tree_568'
rm 568.train_all.dat
rm 568.test_all.dat
rm tree_568.m

matlab -nojvm -nodisplay -nosplash -r 'tree_569'
rm 569.train_all.dat
rm 569.test_all.dat
rm tree_569.m

matlab -nojvm -nodisplay -nosplash -r 'tree_570'
rm 570.train_all.dat
rm 570.test_all.dat
rm tree_570.m

matlab -nojvm -nodisplay -nosplash -r 'tree_571'
rm 571.train_all.dat
rm 571.test_all.dat
rm tree_571.m

matlab -nojvm -nodisplay -nosplash -r 'tree_572'
rm 572.train_all.dat
rm 572.test_all.dat
rm tree_572.m

matlab -nojvm -nodisplay -nosplash -r 'tree_573'
rm 573.train_all.dat
rm 573.test_all.dat
rm tree_573.m

matlab -nojvm -nodisplay -nosplash -r 'tree_574'
rm 574.train_all.dat
rm 574.test_all.dat
rm tree_574.m

matlab -nojvm -nodisplay -nosplash -r 'tree_575'
rm 575.train_all.dat
rm 575.test_all.dat
rm tree_575.m

matlab -nojvm -nodisplay -nosplash -r 'tree_576'
rm 576.train_all.dat
rm 576.test_all.dat
rm tree_576.m

matlab -nojvm -nodisplay -nosplash -r 'tree_577'
rm 577.train_all.dat
rm 577.test_all.dat
rm tree_577.m

matlab -nojvm -nodisplay -nosplash -r 'tree_578'
rm 578.train_all.dat
rm 578.test_all.dat
rm tree_578.m

matlab -nojvm -nodisplay -nosplash -r 'tree_579'
rm 579.train_all.dat
rm 579.test_all.dat
rm tree_579.m

matlab -nojvm -nodisplay -nosplash -r 'tree_580'
rm 580.train_all.dat
rm 580.test_all.dat
rm tree_580.m

matlab -nojvm -nodisplay -nosplash -r 'tree_581'
rm 581.train_all.dat
rm 581.test_all.dat
rm tree_581.m

matlab -nojvm -nodisplay -nosplash -r 'tree_582'
rm 582.train_all.dat
rm 582.test_all.dat
rm tree_582.m

matlab -nojvm -nodisplay -nosplash -r 'tree_583'
rm 583.train_all.dat
rm 583.test_all.dat
rm tree_583.m

matlab -nojvm -nodisplay -nosplash -r 'tree_584'
rm 584.train_all.dat
rm 584.test_all.dat
rm tree_584.m

matlab -nojvm -nodisplay -nosplash -r 'tree_585'
rm 585.train_all.dat
rm 585.test_all.dat
rm tree_585.m

matlab -nojvm -nodisplay -nosplash -r 'tree_586'
rm 586.train_all.dat
rm 586.test_all.dat
rm tree_586.m

matlab -nojvm -nodisplay -nosplash -r 'tree_587'
rm 587.train_all.dat
rm 587.test_all.dat
rm tree_587.m

matlab -nojvm -nodisplay -nosplash -r 'tree_588'
rm 588.train_all.dat
rm 588.test_all.dat
rm tree_588.m

