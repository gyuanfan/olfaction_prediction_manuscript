matlab -nojvm -nodisplay -nosplash -r 'tree_295'
rm 295.train_all.dat
rm 295.test_all.dat
rm tree_295.m

matlab -nojvm -nodisplay -nosplash -r 'tree_296'
rm 296.train_all.dat
rm 296.test_all.dat
rm tree_296.m

matlab -nojvm -nodisplay -nosplash -r 'tree_297'
rm 297.train_all.dat
rm 297.test_all.dat
rm tree_297.m

matlab -nojvm -nodisplay -nosplash -r 'tree_298'
rm 298.train_all.dat
rm 298.test_all.dat
rm tree_298.m

matlab -nojvm -nodisplay -nosplash -r 'tree_299'
rm 299.train_all.dat
rm 299.test_all.dat
rm tree_299.m

matlab -nojvm -nodisplay -nosplash -r 'tree_300'
rm 300.train_all.dat
rm 300.test_all.dat
rm tree_300.m

matlab -nojvm -nodisplay -nosplash -r 'tree_301'
rm 301.train_all.dat
rm 301.test_all.dat
rm tree_301.m

matlab -nojvm -nodisplay -nosplash -r 'tree_302'
rm 302.train_all.dat
rm 302.test_all.dat
rm tree_302.m

matlab -nojvm -nodisplay -nosplash -r 'tree_303'
rm 303.train_all.dat
rm 303.test_all.dat
rm tree_303.m

matlab -nojvm -nodisplay -nosplash -r 'tree_304'
rm 304.train_all.dat
rm 304.test_all.dat
rm tree_304.m

matlab -nojvm -nodisplay -nosplash -r 'tree_305'
rm 305.train_all.dat
rm 305.test_all.dat
rm tree_305.m

matlab -nojvm -nodisplay -nosplash -r 'tree_306'
rm 306.train_all.dat
rm 306.test_all.dat
rm tree_306.m

matlab -nojvm -nodisplay -nosplash -r 'tree_307'
rm 307.train_all.dat
rm 307.test_all.dat
rm tree_307.m

matlab -nojvm -nodisplay -nosplash -r 'tree_308'
rm 308.train_all.dat
rm 308.test_all.dat
rm tree_308.m

matlab -nojvm -nodisplay -nosplash -r 'tree_309'
rm 309.train_all.dat
rm 309.test_all.dat
rm tree_309.m

matlab -nojvm -nodisplay -nosplash -r 'tree_310'
rm 310.train_all.dat
rm 310.test_all.dat
rm tree_310.m

matlab -nojvm -nodisplay -nosplash -r 'tree_311'
rm 311.train_all.dat
rm 311.test_all.dat
rm tree_311.m

matlab -nojvm -nodisplay -nosplash -r 'tree_312'
rm 312.train_all.dat
rm 312.test_all.dat
rm tree_312.m

matlab -nojvm -nodisplay -nosplash -r 'tree_313'
rm 313.train_all.dat
rm 313.test_all.dat
rm tree_313.m

matlab -nojvm -nodisplay -nosplash -r 'tree_314'
rm 314.train_all.dat
rm 314.test_all.dat
rm tree_314.m

matlab -nojvm -nodisplay -nosplash -r 'tree_315'
rm 315.train_all.dat
rm 315.test_all.dat
rm tree_315.m

matlab -nojvm -nodisplay -nosplash -r 'tree_316'
rm 316.train_all.dat
rm 316.test_all.dat
rm tree_316.m

matlab -nojvm -nodisplay -nosplash -r 'tree_317'
rm 317.train_all.dat
rm 317.test_all.dat
rm tree_317.m

matlab -nojvm -nodisplay -nosplash -r 'tree_318'
rm 318.train_all.dat
rm 318.test_all.dat
rm tree_318.m

matlab -nojvm -nodisplay -nosplash -r 'tree_319'
rm 319.train_all.dat
rm 319.test_all.dat
rm tree_319.m

matlab -nojvm -nodisplay -nosplash -r 'tree_320'
rm 320.train_all.dat
rm 320.test_all.dat
rm tree_320.m

matlab -nojvm -nodisplay -nosplash -r 'tree_321'
rm 321.train_all.dat
rm 321.test_all.dat
rm tree_321.m

matlab -nojvm -nodisplay -nosplash -r 'tree_322'
rm 322.train_all.dat
rm 322.test_all.dat
rm tree_322.m

matlab -nojvm -nodisplay -nosplash -r 'tree_323'
rm 323.train_all.dat
rm 323.test_all.dat
rm tree_323.m

matlab -nojvm -nodisplay -nosplash -r 'tree_324'
rm 324.train_all.dat
rm 324.test_all.dat
rm tree_324.m

matlab -nojvm -nodisplay -nosplash -r 'tree_325'
rm 325.train_all.dat
rm 325.test_all.dat
rm tree_325.m

matlab -nojvm -nodisplay -nosplash -r 'tree_326'
rm 326.train_all.dat
rm 326.test_all.dat
rm tree_326.m

matlab -nojvm -nodisplay -nosplash -r 'tree_327'
rm 327.train_all.dat
rm 327.test_all.dat
rm tree_327.m

matlab -nojvm -nodisplay -nosplash -r 'tree_328'
rm 328.train_all.dat
rm 328.test_all.dat
rm tree_328.m

matlab -nojvm -nodisplay -nosplash -r 'tree_329'
rm 329.train_all.dat
rm 329.test_all.dat
rm tree_329.m

matlab -nojvm -nodisplay -nosplash -r 'tree_330'
rm 330.train_all.dat
rm 330.test_all.dat
rm tree_330.m

matlab -nojvm -nodisplay -nosplash -r 'tree_331'
rm 331.train_all.dat
rm 331.test_all.dat
rm tree_331.m

matlab -nojvm -nodisplay -nosplash -r 'tree_332'
rm 332.train_all.dat
rm 332.test_all.dat
rm tree_332.m

matlab -nojvm -nodisplay -nosplash -r 'tree_333'
rm 333.train_all.dat
rm 333.test_all.dat
rm tree_333.m

matlab -nojvm -nodisplay -nosplash -r 'tree_334'
rm 334.train_all.dat
rm 334.test_all.dat
rm tree_334.m

matlab -nojvm -nodisplay -nosplash -r 'tree_335'
rm 335.train_all.dat
rm 335.test_all.dat
rm tree_335.m

matlab -nojvm -nodisplay -nosplash -r 'tree_336'
rm 336.train_all.dat
rm 336.test_all.dat
rm tree_336.m

matlab -nojvm -nodisplay -nosplash -r 'tree_337'
rm 337.train_all.dat
rm 337.test_all.dat
rm tree_337.m

matlab -nojvm -nodisplay -nosplash -r 'tree_338'
rm 338.train_all.dat
rm 338.test_all.dat
rm tree_338.m

matlab -nojvm -nodisplay -nosplash -r 'tree_339'
rm 339.train_all.dat
rm 339.test_all.dat
rm tree_339.m

matlab -nojvm -nodisplay -nosplash -r 'tree_340'
rm 340.train_all.dat
rm 340.test_all.dat
rm tree_340.m

matlab -nojvm -nodisplay -nosplash -r 'tree_341'
rm 341.train_all.dat
rm 341.test_all.dat
rm tree_341.m

matlab -nojvm -nodisplay -nosplash -r 'tree_342'
rm 342.train_all.dat
rm 342.test_all.dat
rm tree_342.m

matlab -nojvm -nodisplay -nosplash -r 'tree_343'
rm 343.train_all.dat
rm 343.test_all.dat
rm tree_343.m

