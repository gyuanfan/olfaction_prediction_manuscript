matlab -nojvm -nodisplay -nosplash -r 'tree_491'
rm 491.train_all.dat
rm 491.test_all.dat
rm tree_491.m

matlab -nojvm -nodisplay -nosplash -r 'tree_492'
rm 492.train_all.dat
rm 492.test_all.dat
rm tree_492.m

matlab -nojvm -nodisplay -nosplash -r 'tree_493'
rm 493.train_all.dat
rm 493.test_all.dat
rm tree_493.m

matlab -nojvm -nodisplay -nosplash -r 'tree_494'
rm 494.train_all.dat
rm 494.test_all.dat
rm tree_494.m

matlab -nojvm -nodisplay -nosplash -r 'tree_495'
rm 495.train_all.dat
rm 495.test_all.dat
rm tree_495.m

matlab -nojvm -nodisplay -nosplash -r 'tree_496'
rm 496.train_all.dat
rm 496.test_all.dat
rm tree_496.m

matlab -nojvm -nodisplay -nosplash -r 'tree_497'
rm 497.train_all.dat
rm 497.test_all.dat
rm tree_497.m

matlab -nojvm -nodisplay -nosplash -r 'tree_498'
rm 498.train_all.dat
rm 498.test_all.dat
rm tree_498.m

matlab -nojvm -nodisplay -nosplash -r 'tree_499'
rm 499.train_all.dat
rm 499.test_all.dat
rm tree_499.m

matlab -nojvm -nodisplay -nosplash -r 'tree_500'
rm 500.train_all.dat
rm 500.test_all.dat
rm tree_500.m

matlab -nojvm -nodisplay -nosplash -r 'tree_501'
rm 501.train_all.dat
rm 501.test_all.dat
rm tree_501.m

matlab -nojvm -nodisplay -nosplash -r 'tree_502'
rm 502.train_all.dat
rm 502.test_all.dat
rm tree_502.m

matlab -nojvm -nodisplay -nosplash -r 'tree_503'
rm 503.train_all.dat
rm 503.test_all.dat
rm tree_503.m

matlab -nojvm -nodisplay -nosplash -r 'tree_504'
rm 504.train_all.dat
rm 504.test_all.dat
rm tree_504.m

matlab -nojvm -nodisplay -nosplash -r 'tree_505'
rm 505.train_all.dat
rm 505.test_all.dat
rm tree_505.m

matlab -nojvm -nodisplay -nosplash -r 'tree_506'
rm 506.train_all.dat
rm 506.test_all.dat
rm tree_506.m

matlab -nojvm -nodisplay -nosplash -r 'tree_507'
rm 507.train_all.dat
rm 507.test_all.dat
rm tree_507.m

matlab -nojvm -nodisplay -nosplash -r 'tree_508'
rm 508.train_all.dat
rm 508.test_all.dat
rm tree_508.m

matlab -nojvm -nodisplay -nosplash -r 'tree_509'
rm 509.train_all.dat
rm 509.test_all.dat
rm tree_509.m

matlab -nojvm -nodisplay -nosplash -r 'tree_510'
rm 510.train_all.dat
rm 510.test_all.dat
rm tree_510.m

matlab -nojvm -nodisplay -nosplash -r 'tree_511'
rm 511.train_all.dat
rm 511.test_all.dat
rm tree_511.m

matlab -nojvm -nodisplay -nosplash -r 'tree_512'
rm 512.train_all.dat
rm 512.test_all.dat
rm tree_512.m

matlab -nojvm -nodisplay -nosplash -r 'tree_513'
rm 513.train_all.dat
rm 513.test_all.dat
rm tree_513.m

matlab -nojvm -nodisplay -nosplash -r 'tree_514'
rm 514.train_all.dat
rm 514.test_all.dat
rm tree_514.m

matlab -nojvm -nodisplay -nosplash -r 'tree_515'
rm 515.train_all.dat
rm 515.test_all.dat
rm tree_515.m

matlab -nojvm -nodisplay -nosplash -r 'tree_516'
rm 516.train_all.dat
rm 516.test_all.dat
rm tree_516.m

matlab -nojvm -nodisplay -nosplash -r 'tree_517'
rm 517.train_all.dat
rm 517.test_all.dat
rm tree_517.m

matlab -nojvm -nodisplay -nosplash -r 'tree_518'
rm 518.train_all.dat
rm 518.test_all.dat
rm tree_518.m

matlab -nojvm -nodisplay -nosplash -r 'tree_519'
rm 519.train_all.dat
rm 519.test_all.dat
rm tree_519.m

matlab -nojvm -nodisplay -nosplash -r 'tree_520'
rm 520.train_all.dat
rm 520.test_all.dat
rm tree_520.m

matlab -nojvm -nodisplay -nosplash -r 'tree_521'
rm 521.train_all.dat
rm 521.test_all.dat
rm tree_521.m

matlab -nojvm -nodisplay -nosplash -r 'tree_522'
rm 522.train_all.dat
rm 522.test_all.dat
rm tree_522.m

matlab -nojvm -nodisplay -nosplash -r 'tree_523'
rm 523.train_all.dat
rm 523.test_all.dat
rm tree_523.m

matlab -nojvm -nodisplay -nosplash -r 'tree_524'
rm 524.train_all.dat
rm 524.test_all.dat
rm tree_524.m

matlab -nojvm -nodisplay -nosplash -r 'tree_525'
rm 525.train_all.dat
rm 525.test_all.dat
rm tree_525.m

matlab -nojvm -nodisplay -nosplash -r 'tree_526'
rm 526.train_all.dat
rm 526.test_all.dat
rm tree_526.m

matlab -nojvm -nodisplay -nosplash -r 'tree_527'
rm 527.train_all.dat
rm 527.test_all.dat
rm tree_527.m

matlab -nojvm -nodisplay -nosplash -r 'tree_528'
rm 528.train_all.dat
rm 528.test_all.dat
rm tree_528.m

matlab -nojvm -nodisplay -nosplash -r 'tree_529'
rm 529.train_all.dat
rm 529.test_all.dat
rm tree_529.m

matlab -nojvm -nodisplay -nosplash -r 'tree_530'
rm 530.train_all.dat
rm 530.test_all.dat
rm tree_530.m

matlab -nojvm -nodisplay -nosplash -r 'tree_531'
rm 531.train_all.dat
rm 531.test_all.dat
rm tree_531.m

matlab -nojvm -nodisplay -nosplash -r 'tree_532'
rm 532.train_all.dat
rm 532.test_all.dat
rm tree_532.m

matlab -nojvm -nodisplay -nosplash -r 'tree_533'
rm 533.train_all.dat
rm 533.test_all.dat
rm tree_533.m

matlab -nojvm -nodisplay -nosplash -r 'tree_534'
rm 534.train_all.dat
rm 534.test_all.dat
rm tree_534.m

matlab -nojvm -nodisplay -nosplash -r 'tree_535'
rm 535.train_all.dat
rm 535.test_all.dat
rm tree_535.m

matlab -nojvm -nodisplay -nosplash -r 'tree_536'
rm 536.train_all.dat
rm 536.test_all.dat
rm tree_536.m

matlab -nojvm -nodisplay -nosplash -r 'tree_537'
rm 537.train_all.dat
rm 537.test_all.dat
rm tree_537.m

matlab -nojvm -nodisplay -nosplash -r 'tree_538'
rm 538.train_all.dat
rm 538.test_all.dat
rm tree_538.m

matlab -nojvm -nodisplay -nosplash -r 'tree_539'
rm 539.train_all.dat
rm 539.test_all.dat
rm tree_539.m

