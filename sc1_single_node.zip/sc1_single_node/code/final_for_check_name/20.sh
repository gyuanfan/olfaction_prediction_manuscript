matlab -nojvm -nodisplay -nosplash -r 'tree_932'
rm 932.train_all.dat
rm 932.test_all.dat
rm tree_932.m

matlab -nojvm -nodisplay -nosplash -r 'tree_933'
rm 933.train_all.dat
rm 933.test_all.dat
rm tree_933.m

matlab -nojvm -nodisplay -nosplash -r 'tree_934'
rm 934.train_all.dat
rm 934.test_all.dat
rm tree_934.m

matlab -nojvm -nodisplay -nosplash -r 'tree_935'
rm 935.train_all.dat
rm 935.test_all.dat
rm tree_935.m

matlab -nojvm -nodisplay -nosplash -r 'tree_936'
rm 936.train_all.dat
rm 936.test_all.dat
rm tree_936.m

matlab -nojvm -nodisplay -nosplash -r 'tree_937'
rm 937.train_all.dat
rm 937.test_all.dat
rm tree_937.m

matlab -nojvm -nodisplay -nosplash -r 'tree_938'
rm 938.train_all.dat
rm 938.test_all.dat
rm tree_938.m

matlab -nojvm -nodisplay -nosplash -r 'tree_939'
rm 939.train_all.dat
rm 939.test_all.dat
rm tree_939.m

matlab -nojvm -nodisplay -nosplash -r 'tree_940'
rm 940.train_all.dat
rm 940.test_all.dat
rm tree_940.m

matlab -nojvm -nodisplay -nosplash -r 'tree_941'
rm 941.train_all.dat
rm 941.test_all.dat
rm tree_941.m

matlab -nojvm -nodisplay -nosplash -r 'tree_942'
rm 942.train_all.dat
rm 942.test_all.dat
rm tree_942.m

matlab -nojvm -nodisplay -nosplash -r 'tree_943'
rm 943.train_all.dat
rm 943.test_all.dat
rm tree_943.m

matlab -nojvm -nodisplay -nosplash -r 'tree_944'
rm 944.train_all.dat
rm 944.test_all.dat
rm tree_944.m

matlab -nojvm -nodisplay -nosplash -r 'tree_945'
rm 945.train_all.dat
rm 945.test_all.dat
rm tree_945.m

matlab -nojvm -nodisplay -nosplash -r 'tree_946'
rm 946.train_all.dat
rm 946.test_all.dat
rm tree_946.m

matlab -nojvm -nodisplay -nosplash -r 'tree_947'
rm 947.train_all.dat
rm 947.test_all.dat
rm tree_947.m

matlab -nojvm -nodisplay -nosplash -r 'tree_948'
rm 948.train_all.dat
rm 948.test_all.dat
rm tree_948.m

matlab -nojvm -nodisplay -nosplash -r 'tree_949'
rm 949.train_all.dat
rm 949.test_all.dat
rm tree_949.m

matlab -nojvm -nodisplay -nosplash -r 'tree_950'
rm 950.train_all.dat
rm 950.test_all.dat
rm tree_950.m

matlab -nojvm -nodisplay -nosplash -r 'tree_951'
rm 951.train_all.dat
rm 951.test_all.dat
rm tree_951.m

matlab -nojvm -nodisplay -nosplash -r 'tree_952'
rm 952.train_all.dat
rm 952.test_all.dat
rm tree_952.m

matlab -nojvm -nodisplay -nosplash -r 'tree_953'
rm 953.train_all.dat
rm 953.test_all.dat
rm tree_953.m

matlab -nojvm -nodisplay -nosplash -r 'tree_954'
rm 954.train_all.dat
rm 954.test_all.dat
rm tree_954.m

matlab -nojvm -nodisplay -nosplash -r 'tree_955'
rm 955.train_all.dat
rm 955.test_all.dat
rm tree_955.m

matlab -nojvm -nodisplay -nosplash -r 'tree_956'
rm 956.train_all.dat
rm 956.test_all.dat
rm tree_956.m

matlab -nojvm -nodisplay -nosplash -r 'tree_957'
rm 957.train_all.dat
rm 957.test_all.dat
rm tree_957.m

matlab -nojvm -nodisplay -nosplash -r 'tree_958'
rm 958.train_all.dat
rm 958.test_all.dat
rm tree_958.m

matlab -nojvm -nodisplay -nosplash -r 'tree_959'
rm 959.train_all.dat
rm 959.test_all.dat
rm tree_959.m

matlab -nojvm -nodisplay -nosplash -r 'tree_960'
rm 960.train_all.dat
rm 960.test_all.dat
rm tree_960.m

matlab -nojvm -nodisplay -nosplash -r 'tree_961'
rm 961.train_all.dat
rm 961.test_all.dat
rm tree_961.m

matlab -nojvm -nodisplay -nosplash -r 'tree_962'
rm 962.train_all.dat
rm 962.test_all.dat
rm tree_962.m

matlab -nojvm -nodisplay -nosplash -r 'tree_963'
rm 963.train_all.dat
rm 963.test_all.dat
rm tree_963.m

matlab -nojvm -nodisplay -nosplash -r 'tree_964'
rm 964.train_all.dat
rm 964.test_all.dat
rm tree_964.m

matlab -nojvm -nodisplay -nosplash -r 'tree_965'
rm 965.train_all.dat
rm 965.test_all.dat
rm tree_965.m

matlab -nojvm -nodisplay -nosplash -r 'tree_966'
rm 966.train_all.dat
rm 966.test_all.dat
rm tree_966.m

matlab -nojvm -nodisplay -nosplash -r 'tree_967'
rm 967.train_all.dat
rm 967.test_all.dat
rm tree_967.m

matlab -nojvm -nodisplay -nosplash -r 'tree_968'
rm 968.train_all.dat
rm 968.test_all.dat
rm tree_968.m

matlab -nojvm -nodisplay -nosplash -r 'tree_969'
rm 969.train_all.dat
rm 969.test_all.dat
rm tree_969.m

matlab -nojvm -nodisplay -nosplash -r 'tree_970'
rm 970.train_all.dat
rm 970.test_all.dat
rm tree_970.m

matlab -nojvm -nodisplay -nosplash -r 'tree_971'
rm 971.train_all.dat
rm 971.test_all.dat
rm tree_971.m

matlab -nojvm -nodisplay -nosplash -r 'tree_972'
rm 972.train_all.dat
rm 972.test_all.dat
rm tree_972.m

matlab -nojvm -nodisplay -nosplash -r 'tree_973'
rm 973.train_all.dat
rm 973.test_all.dat
rm tree_973.m

matlab -nojvm -nodisplay -nosplash -r 'tree_974'
rm 974.train_all.dat
rm 974.test_all.dat
rm tree_974.m

matlab -nojvm -nodisplay -nosplash -r 'tree_975'
rm 975.train_all.dat
rm 975.test_all.dat
rm tree_975.m

matlab -nojvm -nodisplay -nosplash -r 'tree_976'
rm 976.train_all.dat
rm 976.test_all.dat
rm tree_976.m

matlab -nojvm -nodisplay -nosplash -r 'tree_977'
rm 977.train_all.dat
rm 977.test_all.dat
rm tree_977.m

matlab -nojvm -nodisplay -nosplash -r 'tree_978'
rm 978.train_all.dat
rm 978.test_all.dat
rm tree_978.m

matlab -nojvm -nodisplay -nosplash -r 'tree_979'
rm 979.train_all.dat
rm 979.test_all.dat
rm tree_979.m

matlab -nojvm -nodisplay -nosplash -r 'tree_980'
rm 980.train_all.dat
rm 980.test_all.dat
rm tree_980.m

