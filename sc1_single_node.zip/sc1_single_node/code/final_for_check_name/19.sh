matlab -nojvm -nodisplay -nosplash -r 'tree_883'
rm 883.train_all.dat
rm 883.test_all.dat
rm tree_883.m

matlab -nojvm -nodisplay -nosplash -r 'tree_884'
rm 884.train_all.dat
rm 884.test_all.dat
rm tree_884.m

matlab -nojvm -nodisplay -nosplash -r 'tree_885'
rm 885.train_all.dat
rm 885.test_all.dat
rm tree_885.m

matlab -nojvm -nodisplay -nosplash -r 'tree_886'
rm 886.train_all.dat
rm 886.test_all.dat
rm tree_886.m

matlab -nojvm -nodisplay -nosplash -r 'tree_887'
rm 887.train_all.dat
rm 887.test_all.dat
rm tree_887.m

matlab -nojvm -nodisplay -nosplash -r 'tree_888'
rm 888.train_all.dat
rm 888.test_all.dat
rm tree_888.m

matlab -nojvm -nodisplay -nosplash -r 'tree_889'
rm 889.train_all.dat
rm 889.test_all.dat
rm tree_889.m

matlab -nojvm -nodisplay -nosplash -r 'tree_890'
rm 890.train_all.dat
rm 890.test_all.dat
rm tree_890.m

matlab -nojvm -nodisplay -nosplash -r 'tree_891'
rm 891.train_all.dat
rm 891.test_all.dat
rm tree_891.m

matlab -nojvm -nodisplay -nosplash -r 'tree_892'
rm 892.train_all.dat
rm 892.test_all.dat
rm tree_892.m

matlab -nojvm -nodisplay -nosplash -r 'tree_893'
rm 893.train_all.dat
rm 893.test_all.dat
rm tree_893.m

matlab -nojvm -nodisplay -nosplash -r 'tree_894'
rm 894.train_all.dat
rm 894.test_all.dat
rm tree_894.m

matlab -nojvm -nodisplay -nosplash -r 'tree_895'
rm 895.train_all.dat
rm 895.test_all.dat
rm tree_895.m

matlab -nojvm -nodisplay -nosplash -r 'tree_896'
rm 896.train_all.dat
rm 896.test_all.dat
rm tree_896.m

matlab -nojvm -nodisplay -nosplash -r 'tree_897'
rm 897.train_all.dat
rm 897.test_all.dat
rm tree_897.m

matlab -nojvm -nodisplay -nosplash -r 'tree_898'
rm 898.train_all.dat
rm 898.test_all.dat
rm tree_898.m

matlab -nojvm -nodisplay -nosplash -r 'tree_899'
rm 899.train_all.dat
rm 899.test_all.dat
rm tree_899.m

matlab -nojvm -nodisplay -nosplash -r 'tree_900'
rm 900.train_all.dat
rm 900.test_all.dat
rm tree_900.m

matlab -nojvm -nodisplay -nosplash -r 'tree_901'
rm 901.train_all.dat
rm 901.test_all.dat
rm tree_901.m

matlab -nojvm -nodisplay -nosplash -r 'tree_902'
rm 902.train_all.dat
rm 902.test_all.dat
rm tree_902.m

matlab -nojvm -nodisplay -nosplash -r 'tree_903'
rm 903.train_all.dat
rm 903.test_all.dat
rm tree_903.m

matlab -nojvm -nodisplay -nosplash -r 'tree_904'
rm 904.train_all.dat
rm 904.test_all.dat
rm tree_904.m

matlab -nojvm -nodisplay -nosplash -r 'tree_905'
rm 905.train_all.dat
rm 905.test_all.dat
rm tree_905.m

matlab -nojvm -nodisplay -nosplash -r 'tree_906'
rm 906.train_all.dat
rm 906.test_all.dat
rm tree_906.m

matlab -nojvm -nodisplay -nosplash -r 'tree_907'
rm 907.train_all.dat
rm 907.test_all.dat
rm tree_907.m

matlab -nojvm -nodisplay -nosplash -r 'tree_908'
rm 908.train_all.dat
rm 908.test_all.dat
rm tree_908.m

matlab -nojvm -nodisplay -nosplash -r 'tree_909'
rm 909.train_all.dat
rm 909.test_all.dat
rm tree_909.m

matlab -nojvm -nodisplay -nosplash -r 'tree_910'
rm 910.train_all.dat
rm 910.test_all.dat
rm tree_910.m

matlab -nojvm -nodisplay -nosplash -r 'tree_911'
rm 911.train_all.dat
rm 911.test_all.dat
rm tree_911.m

matlab -nojvm -nodisplay -nosplash -r 'tree_912'
rm 912.train_all.dat
rm 912.test_all.dat
rm tree_912.m

matlab -nojvm -nodisplay -nosplash -r 'tree_913'
rm 913.train_all.dat
rm 913.test_all.dat
rm tree_913.m

matlab -nojvm -nodisplay -nosplash -r 'tree_914'
rm 914.train_all.dat
rm 914.test_all.dat
rm tree_914.m

matlab -nojvm -nodisplay -nosplash -r 'tree_915'
rm 915.train_all.dat
rm 915.test_all.dat
rm tree_915.m

matlab -nojvm -nodisplay -nosplash -r 'tree_916'
rm 916.train_all.dat
rm 916.test_all.dat
rm tree_916.m

matlab -nojvm -nodisplay -nosplash -r 'tree_917'
rm 917.train_all.dat
rm 917.test_all.dat
rm tree_917.m

matlab -nojvm -nodisplay -nosplash -r 'tree_918'
rm 918.train_all.dat
rm 918.test_all.dat
rm tree_918.m

matlab -nojvm -nodisplay -nosplash -r 'tree_919'
rm 919.train_all.dat
rm 919.test_all.dat
rm tree_919.m

matlab -nojvm -nodisplay -nosplash -r 'tree_920'
rm 920.train_all.dat
rm 920.test_all.dat
rm tree_920.m

matlab -nojvm -nodisplay -nosplash -r 'tree_921'
rm 921.train_all.dat
rm 921.test_all.dat
rm tree_921.m

matlab -nojvm -nodisplay -nosplash -r 'tree_922'
rm 922.train_all.dat
rm 922.test_all.dat
rm tree_922.m

matlab -nojvm -nodisplay -nosplash -r 'tree_923'
rm 923.train_all.dat
rm 923.test_all.dat
rm tree_923.m

matlab -nojvm -nodisplay -nosplash -r 'tree_924'
rm 924.train_all.dat
rm 924.test_all.dat
rm tree_924.m

matlab -nojvm -nodisplay -nosplash -r 'tree_925'
rm 925.train_all.dat
rm 925.test_all.dat
rm tree_925.m

matlab -nojvm -nodisplay -nosplash -r 'tree_926'
rm 926.train_all.dat
rm 926.test_all.dat
rm tree_926.m

matlab -nojvm -nodisplay -nosplash -r 'tree_927'
rm 927.train_all.dat
rm 927.test_all.dat
rm tree_927.m

matlab -nojvm -nodisplay -nosplash -r 'tree_928'
rm 928.train_all.dat
rm 928.test_all.dat
rm tree_928.m

matlab -nojvm -nodisplay -nosplash -r 'tree_929'
rm 929.train_all.dat
rm 929.test_all.dat
rm tree_929.m

matlab -nojvm -nodisplay -nosplash -r 'tree_930'
rm 930.train_all.dat
rm 930.test_all.dat
rm tree_930.m

matlab -nojvm -nodisplay -nosplash -r 'tree_931'
rm 931.train_all.dat
rm 931.test_all.dat
rm tree_931.m

