matlab -nojvm -nodisplay -nosplash -r 'tree_834'
rm 834.train_all.dat
rm 834.test_all.dat
rm tree_834.m

matlab -nojvm -nodisplay -nosplash -r 'tree_835'
rm 835.train_all.dat
rm 835.test_all.dat
rm tree_835.m

matlab -nojvm -nodisplay -nosplash -r 'tree_836'
rm 836.train_all.dat
rm 836.test_all.dat
rm tree_836.m

matlab -nojvm -nodisplay -nosplash -r 'tree_837'
rm 837.train_all.dat
rm 837.test_all.dat
rm tree_837.m

matlab -nojvm -nodisplay -nosplash -r 'tree_838'
rm 838.train_all.dat
rm 838.test_all.dat
rm tree_838.m

matlab -nojvm -nodisplay -nosplash -r 'tree_839'
rm 839.train_all.dat
rm 839.test_all.dat
rm tree_839.m

matlab -nojvm -nodisplay -nosplash -r 'tree_840'
rm 840.train_all.dat
rm 840.test_all.dat
rm tree_840.m

matlab -nojvm -nodisplay -nosplash -r 'tree_841'
rm 841.train_all.dat
rm 841.test_all.dat
rm tree_841.m

matlab -nojvm -nodisplay -nosplash -r 'tree_842'
rm 842.train_all.dat
rm 842.test_all.dat
rm tree_842.m

matlab -nojvm -nodisplay -nosplash -r 'tree_843'
rm 843.train_all.dat
rm 843.test_all.dat
rm tree_843.m

matlab -nojvm -nodisplay -nosplash -r 'tree_844'
rm 844.train_all.dat
rm 844.test_all.dat
rm tree_844.m

matlab -nojvm -nodisplay -nosplash -r 'tree_845'
rm 845.train_all.dat
rm 845.test_all.dat
rm tree_845.m

matlab -nojvm -nodisplay -nosplash -r 'tree_846'
rm 846.train_all.dat
rm 846.test_all.dat
rm tree_846.m

matlab -nojvm -nodisplay -nosplash -r 'tree_847'
rm 847.train_all.dat
rm 847.test_all.dat
rm tree_847.m

matlab -nojvm -nodisplay -nosplash -r 'tree_848'
rm 848.train_all.dat
rm 848.test_all.dat
rm tree_848.m

matlab -nojvm -nodisplay -nosplash -r 'tree_849'
rm 849.train_all.dat
rm 849.test_all.dat
rm tree_849.m

matlab -nojvm -nodisplay -nosplash -r 'tree_850'
rm 850.train_all.dat
rm 850.test_all.dat
rm tree_850.m

matlab -nojvm -nodisplay -nosplash -r 'tree_851'
rm 851.train_all.dat
rm 851.test_all.dat
rm tree_851.m

matlab -nojvm -nodisplay -nosplash -r 'tree_852'
rm 852.train_all.dat
rm 852.test_all.dat
rm tree_852.m

matlab -nojvm -nodisplay -nosplash -r 'tree_853'
rm 853.train_all.dat
rm 853.test_all.dat
rm tree_853.m

matlab -nojvm -nodisplay -nosplash -r 'tree_854'
rm 854.train_all.dat
rm 854.test_all.dat
rm tree_854.m

matlab -nojvm -nodisplay -nosplash -r 'tree_855'
rm 855.train_all.dat
rm 855.test_all.dat
rm tree_855.m

matlab -nojvm -nodisplay -nosplash -r 'tree_856'
rm 856.train_all.dat
rm 856.test_all.dat
rm tree_856.m

matlab -nojvm -nodisplay -nosplash -r 'tree_857'
rm 857.train_all.dat
rm 857.test_all.dat
rm tree_857.m

matlab -nojvm -nodisplay -nosplash -r 'tree_858'
rm 858.train_all.dat
rm 858.test_all.dat
rm tree_858.m

matlab -nojvm -nodisplay -nosplash -r 'tree_859'
rm 859.train_all.dat
rm 859.test_all.dat
rm tree_859.m

matlab -nojvm -nodisplay -nosplash -r 'tree_860'
rm 860.train_all.dat
rm 860.test_all.dat
rm tree_860.m

matlab -nojvm -nodisplay -nosplash -r 'tree_861'
rm 861.train_all.dat
rm 861.test_all.dat
rm tree_861.m

matlab -nojvm -nodisplay -nosplash -r 'tree_862'
rm 862.train_all.dat
rm 862.test_all.dat
rm tree_862.m

matlab -nojvm -nodisplay -nosplash -r 'tree_863'
rm 863.train_all.dat
rm 863.test_all.dat
rm tree_863.m

matlab -nojvm -nodisplay -nosplash -r 'tree_864'
rm 864.train_all.dat
rm 864.test_all.dat
rm tree_864.m

matlab -nojvm -nodisplay -nosplash -r 'tree_865'
rm 865.train_all.dat
rm 865.test_all.dat
rm tree_865.m

matlab -nojvm -nodisplay -nosplash -r 'tree_866'
rm 866.train_all.dat
rm 866.test_all.dat
rm tree_866.m

matlab -nojvm -nodisplay -nosplash -r 'tree_867'
rm 867.train_all.dat
rm 867.test_all.dat
rm tree_867.m

matlab -nojvm -nodisplay -nosplash -r 'tree_868'
rm 868.train_all.dat
rm 868.test_all.dat
rm tree_868.m

matlab -nojvm -nodisplay -nosplash -r 'tree_869'
rm 869.train_all.dat
rm 869.test_all.dat
rm tree_869.m

matlab -nojvm -nodisplay -nosplash -r 'tree_870'
rm 870.train_all.dat
rm 870.test_all.dat
rm tree_870.m

matlab -nojvm -nodisplay -nosplash -r 'tree_871'
rm 871.train_all.dat
rm 871.test_all.dat
rm tree_871.m

matlab -nojvm -nodisplay -nosplash -r 'tree_872'
rm 872.train_all.dat
rm 872.test_all.dat
rm tree_872.m

matlab -nojvm -nodisplay -nosplash -r 'tree_873'
rm 873.train_all.dat
rm 873.test_all.dat
rm tree_873.m

matlab -nojvm -nodisplay -nosplash -r 'tree_874'
rm 874.train_all.dat
rm 874.test_all.dat
rm tree_874.m

matlab -nojvm -nodisplay -nosplash -r 'tree_875'
rm 875.train_all.dat
rm 875.test_all.dat
rm tree_875.m

matlab -nojvm -nodisplay -nosplash -r 'tree_876'
rm 876.train_all.dat
rm 876.test_all.dat
rm tree_876.m

matlab -nojvm -nodisplay -nosplash -r 'tree_877'
rm 877.train_all.dat
rm 877.test_all.dat
rm tree_877.m

matlab -nojvm -nodisplay -nosplash -r 'tree_878'
rm 878.train_all.dat
rm 878.test_all.dat
rm tree_878.m

matlab -nojvm -nodisplay -nosplash -r 'tree_879'
rm 879.train_all.dat
rm 879.test_all.dat
rm tree_879.m

matlab -nojvm -nodisplay -nosplash -r 'tree_880'
rm 880.train_all.dat
rm 880.test_all.dat
rm tree_880.m

matlab -nojvm -nodisplay -nosplash -r 'tree_881'
rm 881.train_all.dat
rm 881.test_all.dat
rm tree_881.m

matlab -nojvm -nodisplay -nosplash -r 'tree_882'
rm 882.train_all.dat
rm 882.test_all.dat
rm tree_882.m

