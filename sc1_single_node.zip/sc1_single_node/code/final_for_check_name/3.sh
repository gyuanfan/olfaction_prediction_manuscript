matlab -nojvm -nodisplay -nosplash -r 'tree_99'
rm 99.train_all.dat
rm 99.test_all.dat
rm tree_99.m

matlab -nojvm -nodisplay -nosplash -r 'tree_100'
rm 100.train_all.dat
rm 100.test_all.dat
rm tree_100.m

matlab -nojvm -nodisplay -nosplash -r 'tree_101'
rm 101.train_all.dat
rm 101.test_all.dat
rm tree_101.m

matlab -nojvm -nodisplay -nosplash -r 'tree_102'
rm 102.train_all.dat
rm 102.test_all.dat
rm tree_102.m

matlab -nojvm -nodisplay -nosplash -r 'tree_103'
rm 103.train_all.dat
rm 103.test_all.dat
rm tree_103.m

matlab -nojvm -nodisplay -nosplash -r 'tree_104'
rm 104.train_all.dat
rm 104.test_all.dat
rm tree_104.m

matlab -nojvm -nodisplay -nosplash -r 'tree_105'
rm 105.train_all.dat
rm 105.test_all.dat
rm tree_105.m

matlab -nojvm -nodisplay -nosplash -r 'tree_106'
rm 106.train_all.dat
rm 106.test_all.dat
rm tree_106.m

matlab -nojvm -nodisplay -nosplash -r 'tree_107'
rm 107.train_all.dat
rm 107.test_all.dat
rm tree_107.m

matlab -nojvm -nodisplay -nosplash -r 'tree_108'
rm 108.train_all.dat
rm 108.test_all.dat
rm tree_108.m

matlab -nojvm -nodisplay -nosplash -r 'tree_109'
rm 109.train_all.dat
rm 109.test_all.dat
rm tree_109.m

matlab -nojvm -nodisplay -nosplash -r 'tree_110'
rm 110.train_all.dat
rm 110.test_all.dat
rm tree_110.m

matlab -nojvm -nodisplay -nosplash -r 'tree_111'
rm 111.train_all.dat
rm 111.test_all.dat
rm tree_111.m

matlab -nojvm -nodisplay -nosplash -r 'tree_112'
rm 112.train_all.dat
rm 112.test_all.dat
rm tree_112.m

matlab -nojvm -nodisplay -nosplash -r 'tree_113'
rm 113.train_all.dat
rm 113.test_all.dat
rm tree_113.m

matlab -nojvm -nodisplay -nosplash -r 'tree_114'
rm 114.train_all.dat
rm 114.test_all.dat
rm tree_114.m

matlab -nojvm -nodisplay -nosplash -r 'tree_115'
rm 115.train_all.dat
rm 115.test_all.dat
rm tree_115.m

matlab -nojvm -nodisplay -nosplash -r 'tree_116'
rm 116.train_all.dat
rm 116.test_all.dat
rm tree_116.m

matlab -nojvm -nodisplay -nosplash -r 'tree_117'
rm 117.train_all.dat
rm 117.test_all.dat
rm tree_117.m

matlab -nojvm -nodisplay -nosplash -r 'tree_118'
rm 118.train_all.dat
rm 118.test_all.dat
rm tree_118.m

matlab -nojvm -nodisplay -nosplash -r 'tree_119'
rm 119.train_all.dat
rm 119.test_all.dat
rm tree_119.m

matlab -nojvm -nodisplay -nosplash -r 'tree_120'
rm 120.train_all.dat
rm 120.test_all.dat
rm tree_120.m

matlab -nojvm -nodisplay -nosplash -r 'tree_121'
rm 121.train_all.dat
rm 121.test_all.dat
rm tree_121.m

matlab -nojvm -nodisplay -nosplash -r 'tree_122'
rm 122.train_all.dat
rm 122.test_all.dat
rm tree_122.m

matlab -nojvm -nodisplay -nosplash -r 'tree_123'
rm 123.train_all.dat
rm 123.test_all.dat
rm tree_123.m

matlab -nojvm -nodisplay -nosplash -r 'tree_124'
rm 124.train_all.dat
rm 124.test_all.dat
rm tree_124.m

matlab -nojvm -nodisplay -nosplash -r 'tree_125'
rm 125.train_all.dat
rm 125.test_all.dat
rm tree_125.m

matlab -nojvm -nodisplay -nosplash -r 'tree_126'
rm 126.train_all.dat
rm 126.test_all.dat
rm tree_126.m

matlab -nojvm -nodisplay -nosplash -r 'tree_127'
rm 127.train_all.dat
rm 127.test_all.dat
rm tree_127.m

matlab -nojvm -nodisplay -nosplash -r 'tree_128'
rm 128.train_all.dat
rm 128.test_all.dat
rm tree_128.m

matlab -nojvm -nodisplay -nosplash -r 'tree_129'
rm 129.train_all.dat
rm 129.test_all.dat
rm tree_129.m

matlab -nojvm -nodisplay -nosplash -r 'tree_130'
rm 130.train_all.dat
rm 130.test_all.dat
rm tree_130.m

matlab -nojvm -nodisplay -nosplash -r 'tree_131'
rm 131.train_all.dat
rm 131.test_all.dat
rm tree_131.m

matlab -nojvm -nodisplay -nosplash -r 'tree_132'
rm 132.train_all.dat
rm 132.test_all.dat
rm tree_132.m

matlab -nojvm -nodisplay -nosplash -r 'tree_133'
rm 133.train_all.dat
rm 133.test_all.dat
rm tree_133.m

matlab -nojvm -nodisplay -nosplash -r 'tree_134'
rm 134.train_all.dat
rm 134.test_all.dat
rm tree_134.m

matlab -nojvm -nodisplay -nosplash -r 'tree_135'
rm 135.train_all.dat
rm 135.test_all.dat
rm tree_135.m

matlab -nojvm -nodisplay -nosplash -r 'tree_136'
rm 136.train_all.dat
rm 136.test_all.dat
rm tree_136.m

matlab -nojvm -nodisplay -nosplash -r 'tree_137'
rm 137.train_all.dat
rm 137.test_all.dat
rm tree_137.m

matlab -nojvm -nodisplay -nosplash -r 'tree_138'
rm 138.train_all.dat
rm 138.test_all.dat
rm tree_138.m

matlab -nojvm -nodisplay -nosplash -r 'tree_139'
rm 139.train_all.dat
rm 139.test_all.dat
rm tree_139.m

matlab -nojvm -nodisplay -nosplash -r 'tree_140'
rm 140.train_all.dat
rm 140.test_all.dat
rm tree_140.m

matlab -nojvm -nodisplay -nosplash -r 'tree_141'
rm 141.train_all.dat
rm 141.test_all.dat
rm tree_141.m

matlab -nojvm -nodisplay -nosplash -r 'tree_142'
rm 142.train_all.dat
rm 142.test_all.dat
rm tree_142.m

matlab -nojvm -nodisplay -nosplash -r 'tree_143'
rm 143.train_all.dat
rm 143.test_all.dat
rm tree_143.m

matlab -nojvm -nodisplay -nosplash -r 'tree_144'
rm 144.train_all.dat
rm 144.test_all.dat
rm tree_144.m

matlab -nojvm -nodisplay -nosplash -r 'tree_145'
rm 145.train_all.dat
rm 145.test_all.dat
rm tree_145.m

matlab -nojvm -nodisplay -nosplash -r 'tree_146'
rm 146.train_all.dat
rm 146.test_all.dat
rm tree_146.m

matlab -nojvm -nodisplay -nosplash -r 'tree_147'
rm 147.train_all.dat
rm 147.test_all.dat
rm tree_147.m

