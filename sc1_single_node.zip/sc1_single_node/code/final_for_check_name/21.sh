matlab -nojvm -nodisplay -nosplash -r 'tree_981'
rm 981.train_all.dat
rm 981.test_all.dat
rm tree_981.m

matlab -nojvm -nodisplay -nosplash -r 'tree_982'
rm 982.train_all.dat
rm 982.test_all.dat
rm tree_982.m

matlab -nojvm -nodisplay -nosplash -r 'tree_983'
rm 983.train_all.dat
rm 983.test_all.dat
rm tree_983.m

matlab -nojvm -nodisplay -nosplash -r 'tree_984'
rm 984.train_all.dat
rm 984.test_all.dat
rm tree_984.m

matlab -nojvm -nodisplay -nosplash -r 'tree_985'
rm 985.train_all.dat
rm 985.test_all.dat
rm tree_985.m

matlab -nojvm -nodisplay -nosplash -r 'tree_986'
rm 986.train_all.dat
rm 986.test_all.dat
rm tree_986.m

matlab -nojvm -nodisplay -nosplash -r 'tree_987'
rm 987.train_all.dat
rm 987.test_all.dat
rm tree_987.m

matlab -nojvm -nodisplay -nosplash -r 'tree_988'
rm 988.train_all.dat
rm 988.test_all.dat
rm tree_988.m

matlab -nojvm -nodisplay -nosplash -r 'tree_989'
rm 989.train_all.dat
rm 989.test_all.dat
rm tree_989.m

matlab -nojvm -nodisplay -nosplash -r 'tree_990'
rm 990.train_all.dat
rm 990.test_all.dat
rm tree_990.m

matlab -nojvm -nodisplay -nosplash -r 'tree_991'
rm 991.train_all.dat
rm 991.test_all.dat
rm tree_991.m

matlab -nojvm -nodisplay -nosplash -r 'tree_992'
rm 992.train_all.dat
rm 992.test_all.dat
rm tree_992.m

matlab -nojvm -nodisplay -nosplash -r 'tree_993'
rm 993.train_all.dat
rm 993.test_all.dat
rm tree_993.m

matlab -nojvm -nodisplay -nosplash -r 'tree_994'
rm 994.train_all.dat
rm 994.test_all.dat
rm tree_994.m

matlab -nojvm -nodisplay -nosplash -r 'tree_995'
rm 995.train_all.dat
rm 995.test_all.dat
rm tree_995.m

matlab -nojvm -nodisplay -nosplash -r 'tree_996'
rm 996.train_all.dat
rm 996.test_all.dat
rm tree_996.m

matlab -nojvm -nodisplay -nosplash -r 'tree_997'
rm 997.train_all.dat
rm 997.test_all.dat
rm tree_997.m

matlab -nojvm -nodisplay -nosplash -r 'tree_998'
rm 998.train_all.dat
rm 998.test_all.dat
rm tree_998.m

matlab -nojvm -nodisplay -nosplash -r 'tree_999'
rm 999.train_all.dat
rm 999.test_all.dat
rm tree_999.m

matlab -nojvm -nodisplay -nosplash -r 'tree_1000'
rm 1000.train_all.dat
rm 1000.test_all.dat
rm tree_1000.m

matlab -nojvm -nodisplay -nosplash -r 'tree_1001'
rm 1001.train_all.dat
rm 1001.test_all.dat
rm tree_1001.m

matlab -nojvm -nodisplay -nosplash -r 'tree_1002'
rm 1002.train_all.dat
rm 1002.test_all.dat
rm tree_1002.m

matlab -nojvm -nodisplay -nosplash -r 'tree_1003'
rm 1003.train_all.dat
rm 1003.test_all.dat
rm tree_1003.m

matlab -nojvm -nodisplay -nosplash -r 'tree_1004'
rm 1004.train_all.dat
rm 1004.test_all.dat
rm tree_1004.m

matlab -nojvm -nodisplay -nosplash -r 'tree_1005'
rm 1005.train_all.dat
rm 1005.test_all.dat
rm tree_1005.m

matlab -nojvm -nodisplay -nosplash -r 'tree_1006'
rm 1006.train_all.dat
rm 1006.test_all.dat
rm tree_1006.m

matlab -nojvm -nodisplay -nosplash -r 'tree_1007'
rm 1007.train_all.dat
rm 1007.test_all.dat
rm tree_1007.m

matlab -nojvm -nodisplay -nosplash -r 'tree_1008'
rm 1008.train_all.dat
rm 1008.test_all.dat
rm tree_1008.m

matlab -nojvm -nodisplay -nosplash -r 'tree_1009'
rm 1009.train_all.dat
rm 1009.test_all.dat
rm tree_1009.m

matlab -nojvm -nodisplay -nosplash -r 'tree_1010'
rm 1010.train_all.dat
rm 1010.test_all.dat
rm tree_1010.m

matlab -nojvm -nodisplay -nosplash -r 'tree_1011'
rm 1011.train_all.dat
rm 1011.test_all.dat
rm tree_1011.m

matlab -nojvm -nodisplay -nosplash -r 'tree_1012'
rm 1012.train_all.dat
rm 1012.test_all.dat
rm tree_1012.m

matlab -nojvm -nodisplay -nosplash -r 'tree_1013'
rm 1013.train_all.dat
rm 1013.test_all.dat
rm tree_1013.m

matlab -nojvm -nodisplay -nosplash -r 'tree_1014'
rm 1014.train_all.dat
rm 1014.test_all.dat
rm tree_1014.m

matlab -nojvm -nodisplay -nosplash -r 'tree_1015'
rm 1015.train_all.dat
rm 1015.test_all.dat
rm tree_1015.m

matlab -nojvm -nodisplay -nosplash -r 'tree_1016'
rm 1016.train_all.dat
rm 1016.test_all.dat
rm tree_1016.m

matlab -nojvm -nodisplay -nosplash -r 'tree_1017'
rm 1017.train_all.dat
rm 1017.test_all.dat
rm tree_1017.m

matlab -nojvm -nodisplay -nosplash -r 'tree_1018'
rm 1018.train_all.dat
rm 1018.test_all.dat
rm tree_1018.m

matlab -nojvm -nodisplay -nosplash -r 'tree_1019'
rm 1019.train_all.dat
rm 1019.test_all.dat
rm tree_1019.m

matlab -nojvm -nodisplay -nosplash -r 'tree_1020'
rm 1020.train_all.dat
rm 1020.test_all.dat
rm tree_1020.m

matlab -nojvm -nodisplay -nosplash -r 'tree_1021'
rm 1021.train_all.dat
rm 1021.test_all.dat
rm tree_1021.m

matlab -nojvm -nodisplay -nosplash -r 'tree_1022'
rm 1022.train_all.dat
rm 1022.test_all.dat
rm tree_1022.m

matlab -nojvm -nodisplay -nosplash -r 'tree_1023'
rm 1023.train_all.dat
rm 1023.test_all.dat
rm tree_1023.m

matlab -nojvm -nodisplay -nosplash -r 'tree_1024'
rm 1024.train_all.dat
rm 1024.test_all.dat
rm tree_1024.m

matlab -nojvm -nodisplay -nosplash -r 'tree_1025'
rm 1025.train_all.dat
rm 1025.test_all.dat
rm tree_1025.m

matlab -nojvm -nodisplay -nosplash -r 'tree_1026'
rm 1026.train_all.dat
rm 1026.test_all.dat
rm tree_1026.m

matlab -nojvm -nodisplay -nosplash -r 'tree_1027'
rm 1027.train_all.dat
rm 1027.test_all.dat
rm tree_1027.m

matlab -nojvm -nodisplay -nosplash -r 'tree_1028'
rm 1028.train_all.dat
rm 1028.test_all.dat
rm tree_1028.m

matlab -nojvm -nodisplay -nosplash -r 'tree_1029'
rm 1029.train_all.dat
rm 1029.test_all.dat
rm tree_1029.m

