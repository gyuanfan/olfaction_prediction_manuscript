matlab -nojvm -nodisplay -nosplash -r 'tree_736'
rm 736.train_all.dat
rm 736.test_all.dat
rm tree_736.m

matlab -nojvm -nodisplay -nosplash -r 'tree_737'
rm 737.train_all.dat
rm 737.test_all.dat
rm tree_737.m

matlab -nojvm -nodisplay -nosplash -r 'tree_738'
rm 738.train_all.dat
rm 738.test_all.dat
rm tree_738.m

matlab -nojvm -nodisplay -nosplash -r 'tree_739'
rm 739.train_all.dat
rm 739.test_all.dat
rm tree_739.m

matlab -nojvm -nodisplay -nosplash -r 'tree_740'
rm 740.train_all.dat
rm 740.test_all.dat
rm tree_740.m

matlab -nojvm -nodisplay -nosplash -r 'tree_741'
rm 741.train_all.dat
rm 741.test_all.dat
rm tree_741.m

matlab -nojvm -nodisplay -nosplash -r 'tree_742'
rm 742.train_all.dat
rm 742.test_all.dat
rm tree_742.m

matlab -nojvm -nodisplay -nosplash -r 'tree_743'
rm 743.train_all.dat
rm 743.test_all.dat
rm tree_743.m

matlab -nojvm -nodisplay -nosplash -r 'tree_744'
rm 744.train_all.dat
rm 744.test_all.dat
rm tree_744.m

matlab -nojvm -nodisplay -nosplash -r 'tree_745'
rm 745.train_all.dat
rm 745.test_all.dat
rm tree_745.m

matlab -nojvm -nodisplay -nosplash -r 'tree_746'
rm 746.train_all.dat
rm 746.test_all.dat
rm tree_746.m

matlab -nojvm -nodisplay -nosplash -r 'tree_747'
rm 747.train_all.dat
rm 747.test_all.dat
rm tree_747.m

matlab -nojvm -nodisplay -nosplash -r 'tree_748'
rm 748.train_all.dat
rm 748.test_all.dat
rm tree_748.m

matlab -nojvm -nodisplay -nosplash -r 'tree_749'
rm 749.train_all.dat
rm 749.test_all.dat
rm tree_749.m

matlab -nojvm -nodisplay -nosplash -r 'tree_750'
rm 750.train_all.dat
rm 750.test_all.dat
rm tree_750.m

matlab -nojvm -nodisplay -nosplash -r 'tree_751'
rm 751.train_all.dat
rm 751.test_all.dat
rm tree_751.m

matlab -nojvm -nodisplay -nosplash -r 'tree_752'
rm 752.train_all.dat
rm 752.test_all.dat
rm tree_752.m

matlab -nojvm -nodisplay -nosplash -r 'tree_753'
rm 753.train_all.dat
rm 753.test_all.dat
rm tree_753.m

matlab -nojvm -nodisplay -nosplash -r 'tree_754'
rm 754.train_all.dat
rm 754.test_all.dat
rm tree_754.m

matlab -nojvm -nodisplay -nosplash -r 'tree_755'
rm 755.train_all.dat
rm 755.test_all.dat
rm tree_755.m

matlab -nojvm -nodisplay -nosplash -r 'tree_756'
rm 756.train_all.dat
rm 756.test_all.dat
rm tree_756.m

matlab -nojvm -nodisplay -nosplash -r 'tree_757'
rm 757.train_all.dat
rm 757.test_all.dat
rm tree_757.m

matlab -nojvm -nodisplay -nosplash -r 'tree_758'
rm 758.train_all.dat
rm 758.test_all.dat
rm tree_758.m

matlab -nojvm -nodisplay -nosplash -r 'tree_759'
rm 759.train_all.dat
rm 759.test_all.dat
rm tree_759.m

matlab -nojvm -nodisplay -nosplash -r 'tree_760'
rm 760.train_all.dat
rm 760.test_all.dat
rm tree_760.m

matlab -nojvm -nodisplay -nosplash -r 'tree_761'
rm 761.train_all.dat
rm 761.test_all.dat
rm tree_761.m

matlab -nojvm -nodisplay -nosplash -r 'tree_762'
rm 762.train_all.dat
rm 762.test_all.dat
rm tree_762.m

matlab -nojvm -nodisplay -nosplash -r 'tree_763'
rm 763.train_all.dat
rm 763.test_all.dat
rm tree_763.m

matlab -nojvm -nodisplay -nosplash -r 'tree_764'
rm 764.train_all.dat
rm 764.test_all.dat
rm tree_764.m

matlab -nojvm -nodisplay -nosplash -r 'tree_765'
rm 765.train_all.dat
rm 765.test_all.dat
rm tree_765.m

matlab -nojvm -nodisplay -nosplash -r 'tree_766'
rm 766.train_all.dat
rm 766.test_all.dat
rm tree_766.m

matlab -nojvm -nodisplay -nosplash -r 'tree_767'
rm 767.train_all.dat
rm 767.test_all.dat
rm tree_767.m

matlab -nojvm -nodisplay -nosplash -r 'tree_768'
rm 768.train_all.dat
rm 768.test_all.dat
rm tree_768.m

matlab -nojvm -nodisplay -nosplash -r 'tree_769'
rm 769.train_all.dat
rm 769.test_all.dat
rm tree_769.m

matlab -nojvm -nodisplay -nosplash -r 'tree_770'
rm 770.train_all.dat
rm 770.test_all.dat
rm tree_770.m

matlab -nojvm -nodisplay -nosplash -r 'tree_771'
rm 771.train_all.dat
rm 771.test_all.dat
rm tree_771.m

matlab -nojvm -nodisplay -nosplash -r 'tree_772'
rm 772.train_all.dat
rm 772.test_all.dat
rm tree_772.m

matlab -nojvm -nodisplay -nosplash -r 'tree_773'
rm 773.train_all.dat
rm 773.test_all.dat
rm tree_773.m

matlab -nojvm -nodisplay -nosplash -r 'tree_774'
rm 774.train_all.dat
rm 774.test_all.dat
rm tree_774.m

matlab -nojvm -nodisplay -nosplash -r 'tree_775'
rm 775.train_all.dat
rm 775.test_all.dat
rm tree_775.m

matlab -nojvm -nodisplay -nosplash -r 'tree_776'
rm 776.train_all.dat
rm 776.test_all.dat
rm tree_776.m

matlab -nojvm -nodisplay -nosplash -r 'tree_777'
rm 777.train_all.dat
rm 777.test_all.dat
rm tree_777.m

matlab -nojvm -nodisplay -nosplash -r 'tree_778'
rm 778.train_all.dat
rm 778.test_all.dat
rm tree_778.m

matlab -nojvm -nodisplay -nosplash -r 'tree_779'
rm 779.train_all.dat
rm 779.test_all.dat
rm tree_779.m

matlab -nojvm -nodisplay -nosplash -r 'tree_780'
rm 780.train_all.dat
rm 780.test_all.dat
rm tree_780.m

matlab -nojvm -nodisplay -nosplash -r 'tree_781'
rm 781.train_all.dat
rm 781.test_all.dat
rm tree_781.m

matlab -nojvm -nodisplay -nosplash -r 'tree_782'
rm 782.train_all.dat
rm 782.test_all.dat
rm tree_782.m

matlab -nojvm -nodisplay -nosplash -r 'tree_783'
rm 783.train_all.dat
rm 783.test_all.dat
rm tree_783.m

matlab -nojvm -nodisplay -nosplash -r 'tree_784'
rm 784.train_all.dat
rm 784.test_all.dat
rm tree_784.m

