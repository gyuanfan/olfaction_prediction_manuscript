matlab -nojvm -nodisplay -nosplash -r 'tree_197'
rm 197.train_all.dat
rm 197.test_all.dat
rm tree_197.m

matlab -nojvm -nodisplay -nosplash -r 'tree_198'
rm 198.train_all.dat
rm 198.test_all.dat
rm tree_198.m

matlab -nojvm -nodisplay -nosplash -r 'tree_199'
rm 199.train_all.dat
rm 199.test_all.dat
rm tree_199.m

matlab -nojvm -nodisplay -nosplash -r 'tree_200'
rm 200.train_all.dat
rm 200.test_all.dat
rm tree_200.m

matlab -nojvm -nodisplay -nosplash -r 'tree_201'
rm 201.train_all.dat
rm 201.test_all.dat
rm tree_201.m

matlab -nojvm -nodisplay -nosplash -r 'tree_202'
rm 202.train_all.dat
rm 202.test_all.dat
rm tree_202.m

matlab -nojvm -nodisplay -nosplash -r 'tree_203'
rm 203.train_all.dat
rm 203.test_all.dat
rm tree_203.m

matlab -nojvm -nodisplay -nosplash -r 'tree_204'
rm 204.train_all.dat
rm 204.test_all.dat
rm tree_204.m

matlab -nojvm -nodisplay -nosplash -r 'tree_205'
rm 205.train_all.dat
rm 205.test_all.dat
rm tree_205.m

matlab -nojvm -nodisplay -nosplash -r 'tree_206'
rm 206.train_all.dat
rm 206.test_all.dat
rm tree_206.m

matlab -nojvm -nodisplay -nosplash -r 'tree_207'
rm 207.train_all.dat
rm 207.test_all.dat
rm tree_207.m

matlab -nojvm -nodisplay -nosplash -r 'tree_208'
rm 208.train_all.dat
rm 208.test_all.dat
rm tree_208.m

matlab -nojvm -nodisplay -nosplash -r 'tree_209'
rm 209.train_all.dat
rm 209.test_all.dat
rm tree_209.m

matlab -nojvm -nodisplay -nosplash -r 'tree_210'
rm 210.train_all.dat
rm 210.test_all.dat
rm tree_210.m

matlab -nojvm -nodisplay -nosplash -r 'tree_211'
rm 211.train_all.dat
rm 211.test_all.dat
rm tree_211.m

matlab -nojvm -nodisplay -nosplash -r 'tree_212'
rm 212.train_all.dat
rm 212.test_all.dat
rm tree_212.m

matlab -nojvm -nodisplay -nosplash -r 'tree_213'
rm 213.train_all.dat
rm 213.test_all.dat
rm tree_213.m

matlab -nojvm -nodisplay -nosplash -r 'tree_214'
rm 214.train_all.dat
rm 214.test_all.dat
rm tree_214.m

matlab -nojvm -nodisplay -nosplash -r 'tree_215'
rm 215.train_all.dat
rm 215.test_all.dat
rm tree_215.m

matlab -nojvm -nodisplay -nosplash -r 'tree_216'
rm 216.train_all.dat
rm 216.test_all.dat
rm tree_216.m

matlab -nojvm -nodisplay -nosplash -r 'tree_217'
rm 217.train_all.dat
rm 217.test_all.dat
rm tree_217.m

matlab -nojvm -nodisplay -nosplash -r 'tree_218'
rm 218.train_all.dat
rm 218.test_all.dat
rm tree_218.m

matlab -nojvm -nodisplay -nosplash -r 'tree_219'
rm 219.train_all.dat
rm 219.test_all.dat
rm tree_219.m

matlab -nojvm -nodisplay -nosplash -r 'tree_220'
rm 220.train_all.dat
rm 220.test_all.dat
rm tree_220.m

matlab -nojvm -nodisplay -nosplash -r 'tree_221'
rm 221.train_all.dat
rm 221.test_all.dat
rm tree_221.m

matlab -nojvm -nodisplay -nosplash -r 'tree_222'
rm 222.train_all.dat
rm 222.test_all.dat
rm tree_222.m

matlab -nojvm -nodisplay -nosplash -r 'tree_223'
rm 223.train_all.dat
rm 223.test_all.dat
rm tree_223.m

matlab -nojvm -nodisplay -nosplash -r 'tree_224'
rm 224.train_all.dat
rm 224.test_all.dat
rm tree_224.m

matlab -nojvm -nodisplay -nosplash -r 'tree_225'
rm 225.train_all.dat
rm 225.test_all.dat
rm tree_225.m

matlab -nojvm -nodisplay -nosplash -r 'tree_226'
rm 226.train_all.dat
rm 226.test_all.dat
rm tree_226.m

matlab -nojvm -nodisplay -nosplash -r 'tree_227'
rm 227.train_all.dat
rm 227.test_all.dat
rm tree_227.m

matlab -nojvm -nodisplay -nosplash -r 'tree_228'
rm 228.train_all.dat
rm 228.test_all.dat
rm tree_228.m

matlab -nojvm -nodisplay -nosplash -r 'tree_229'
rm 229.train_all.dat
rm 229.test_all.dat
rm tree_229.m

matlab -nojvm -nodisplay -nosplash -r 'tree_230'
rm 230.train_all.dat
rm 230.test_all.dat
rm tree_230.m

matlab -nojvm -nodisplay -nosplash -r 'tree_231'
rm 231.train_all.dat
rm 231.test_all.dat
rm tree_231.m

matlab -nojvm -nodisplay -nosplash -r 'tree_232'
rm 232.train_all.dat
rm 232.test_all.dat
rm tree_232.m

matlab -nojvm -nodisplay -nosplash -r 'tree_233'
rm 233.train_all.dat
rm 233.test_all.dat
rm tree_233.m

matlab -nojvm -nodisplay -nosplash -r 'tree_234'
rm 234.train_all.dat
rm 234.test_all.dat
rm tree_234.m

matlab -nojvm -nodisplay -nosplash -r 'tree_235'
rm 235.train_all.dat
rm 235.test_all.dat
rm tree_235.m

matlab -nojvm -nodisplay -nosplash -r 'tree_236'
rm 236.train_all.dat
rm 236.test_all.dat
rm tree_236.m

matlab -nojvm -nodisplay -nosplash -r 'tree_237'
rm 237.train_all.dat
rm 237.test_all.dat
rm tree_237.m

matlab -nojvm -nodisplay -nosplash -r 'tree_238'
rm 238.train_all.dat
rm 238.test_all.dat
rm tree_238.m

matlab -nojvm -nodisplay -nosplash -r 'tree_239'
rm 239.train_all.dat
rm 239.test_all.dat
rm tree_239.m

matlab -nojvm -nodisplay -nosplash -r 'tree_240'
rm 240.train_all.dat
rm 240.test_all.dat
rm tree_240.m

matlab -nojvm -nodisplay -nosplash -r 'tree_241'
rm 241.train_all.dat
rm 241.test_all.dat
rm tree_241.m

matlab -nojvm -nodisplay -nosplash -r 'tree_242'
rm 242.train_all.dat
rm 242.test_all.dat
rm tree_242.m

matlab -nojvm -nodisplay -nosplash -r 'tree_243'
rm 243.train_all.dat
rm 243.test_all.dat
rm tree_243.m

matlab -nojvm -nodisplay -nosplash -r 'tree_244'
rm 244.train_all.dat
rm 244.test_all.dat
rm tree_244.m

matlab -nojvm -nodisplay -nosplash -r 'tree_245'
rm 245.train_all.dat
rm 245.test_all.dat
rm tree_245.m

