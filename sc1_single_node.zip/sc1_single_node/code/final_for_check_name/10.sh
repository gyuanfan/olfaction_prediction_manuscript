matlab -nojvm -nodisplay -nosplash -r 'tree_442'
rm 442.train_all.dat
rm 442.test_all.dat
rm tree_442.m

matlab -nojvm -nodisplay -nosplash -r 'tree_443'
rm 443.train_all.dat
rm 443.test_all.dat
rm tree_443.m

matlab -nojvm -nodisplay -nosplash -r 'tree_444'
rm 444.train_all.dat
rm 444.test_all.dat
rm tree_444.m

matlab -nojvm -nodisplay -nosplash -r 'tree_445'
rm 445.train_all.dat
rm 445.test_all.dat
rm tree_445.m

matlab -nojvm -nodisplay -nosplash -r 'tree_446'
rm 446.train_all.dat
rm 446.test_all.dat
rm tree_446.m

matlab -nojvm -nodisplay -nosplash -r 'tree_447'
rm 447.train_all.dat
rm 447.test_all.dat
rm tree_447.m

matlab -nojvm -nodisplay -nosplash -r 'tree_448'
rm 448.train_all.dat
rm 448.test_all.dat
rm tree_448.m

matlab -nojvm -nodisplay -nosplash -r 'tree_449'
rm 449.train_all.dat
rm 449.test_all.dat
rm tree_449.m

matlab -nojvm -nodisplay -nosplash -r 'tree_450'
rm 450.train_all.dat
rm 450.test_all.dat
rm tree_450.m

matlab -nojvm -nodisplay -nosplash -r 'tree_451'
rm 451.train_all.dat
rm 451.test_all.dat
rm tree_451.m

matlab -nojvm -nodisplay -nosplash -r 'tree_452'
rm 452.train_all.dat
rm 452.test_all.dat
rm tree_452.m

matlab -nojvm -nodisplay -nosplash -r 'tree_453'
rm 453.train_all.dat
rm 453.test_all.dat
rm tree_453.m

matlab -nojvm -nodisplay -nosplash -r 'tree_454'
rm 454.train_all.dat
rm 454.test_all.dat
rm tree_454.m

matlab -nojvm -nodisplay -nosplash -r 'tree_455'
rm 455.train_all.dat
rm 455.test_all.dat
rm tree_455.m

matlab -nojvm -nodisplay -nosplash -r 'tree_456'
rm 456.train_all.dat
rm 456.test_all.dat
rm tree_456.m

matlab -nojvm -nodisplay -nosplash -r 'tree_457'
rm 457.train_all.dat
rm 457.test_all.dat
rm tree_457.m

matlab -nojvm -nodisplay -nosplash -r 'tree_458'
rm 458.train_all.dat
rm 458.test_all.dat
rm tree_458.m

matlab -nojvm -nodisplay -nosplash -r 'tree_459'
rm 459.train_all.dat
rm 459.test_all.dat
rm tree_459.m

matlab -nojvm -nodisplay -nosplash -r 'tree_460'
rm 460.train_all.dat
rm 460.test_all.dat
rm tree_460.m

matlab -nojvm -nodisplay -nosplash -r 'tree_461'
rm 461.train_all.dat
rm 461.test_all.dat
rm tree_461.m

matlab -nojvm -nodisplay -nosplash -r 'tree_462'
rm 462.train_all.dat
rm 462.test_all.dat
rm tree_462.m

matlab -nojvm -nodisplay -nosplash -r 'tree_463'
rm 463.train_all.dat
rm 463.test_all.dat
rm tree_463.m

matlab -nojvm -nodisplay -nosplash -r 'tree_464'
rm 464.train_all.dat
rm 464.test_all.dat
rm tree_464.m

matlab -nojvm -nodisplay -nosplash -r 'tree_465'
rm 465.train_all.dat
rm 465.test_all.dat
rm tree_465.m

matlab -nojvm -nodisplay -nosplash -r 'tree_466'
rm 466.train_all.dat
rm 466.test_all.dat
rm tree_466.m

matlab -nojvm -nodisplay -nosplash -r 'tree_467'
rm 467.train_all.dat
rm 467.test_all.dat
rm tree_467.m

matlab -nojvm -nodisplay -nosplash -r 'tree_468'
rm 468.train_all.dat
rm 468.test_all.dat
rm tree_468.m

matlab -nojvm -nodisplay -nosplash -r 'tree_469'
rm 469.train_all.dat
rm 469.test_all.dat
rm tree_469.m

matlab -nojvm -nodisplay -nosplash -r 'tree_470'
rm 470.train_all.dat
rm 470.test_all.dat
rm tree_470.m

matlab -nojvm -nodisplay -nosplash -r 'tree_471'
rm 471.train_all.dat
rm 471.test_all.dat
rm tree_471.m

matlab -nojvm -nodisplay -nosplash -r 'tree_472'
rm 472.train_all.dat
rm 472.test_all.dat
rm tree_472.m

matlab -nojvm -nodisplay -nosplash -r 'tree_473'
rm 473.train_all.dat
rm 473.test_all.dat
rm tree_473.m

matlab -nojvm -nodisplay -nosplash -r 'tree_474'
rm 474.train_all.dat
rm 474.test_all.dat
rm tree_474.m

matlab -nojvm -nodisplay -nosplash -r 'tree_475'
rm 475.train_all.dat
rm 475.test_all.dat
rm tree_475.m

matlab -nojvm -nodisplay -nosplash -r 'tree_476'
rm 476.train_all.dat
rm 476.test_all.dat
rm tree_476.m

matlab -nojvm -nodisplay -nosplash -r 'tree_477'
rm 477.train_all.dat
rm 477.test_all.dat
rm tree_477.m

matlab -nojvm -nodisplay -nosplash -r 'tree_478'
rm 478.train_all.dat
rm 478.test_all.dat
rm tree_478.m

matlab -nojvm -nodisplay -nosplash -r 'tree_479'
rm 479.train_all.dat
rm 479.test_all.dat
rm tree_479.m

matlab -nojvm -nodisplay -nosplash -r 'tree_480'
rm 480.train_all.dat
rm 480.test_all.dat
rm tree_480.m

matlab -nojvm -nodisplay -nosplash -r 'tree_481'
rm 481.train_all.dat
rm 481.test_all.dat
rm tree_481.m

matlab -nojvm -nodisplay -nosplash -r 'tree_482'
rm 482.train_all.dat
rm 482.test_all.dat
rm tree_482.m

matlab -nojvm -nodisplay -nosplash -r 'tree_483'
rm 483.train_all.dat
rm 483.test_all.dat
rm tree_483.m

matlab -nojvm -nodisplay -nosplash -r 'tree_484'
rm 484.train_all.dat
rm 484.test_all.dat
rm tree_484.m

matlab -nojvm -nodisplay -nosplash -r 'tree_485'
rm 485.train_all.dat
rm 485.test_all.dat
rm tree_485.m

matlab -nojvm -nodisplay -nosplash -r 'tree_486'
rm 486.train_all.dat
rm 486.test_all.dat
rm tree_486.m

matlab -nojvm -nodisplay -nosplash -r 'tree_487'
rm 487.train_all.dat
rm 487.test_all.dat
rm tree_487.m

matlab -nojvm -nodisplay -nosplash -r 'tree_488'
rm 488.train_all.dat
rm 488.test_all.dat
rm tree_488.m

matlab -nojvm -nodisplay -nosplash -r 'tree_489'
rm 489.train_all.dat
rm 489.test_all.dat
rm tree_489.m

matlab -nojvm -nodisplay -nosplash -r 'tree_490'
rm 490.train_all.dat
rm 490.test_all.dat
rm tree_490.m

