matlab -nojvm -nodisplay -nosplash -r 'tree_50'
rm 50.train_all.dat
rm 50.test_all.dat
rm tree_50.m

matlab -nojvm -nodisplay -nosplash -r 'tree_51'
rm 51.train_all.dat
rm 51.test_all.dat
rm tree_51.m

matlab -nojvm -nodisplay -nosplash -r 'tree_52'
rm 52.train_all.dat
rm 52.test_all.dat
rm tree_52.m

matlab -nojvm -nodisplay -nosplash -r 'tree_53'
rm 53.train_all.dat
rm 53.test_all.dat
rm tree_53.m

matlab -nojvm -nodisplay -nosplash -r 'tree_54'
rm 54.train_all.dat
rm 54.test_all.dat
rm tree_54.m

matlab -nojvm -nodisplay -nosplash -r 'tree_55'
rm 55.train_all.dat
rm 55.test_all.dat
rm tree_55.m

matlab -nojvm -nodisplay -nosplash -r 'tree_56'
rm 56.train_all.dat
rm 56.test_all.dat
rm tree_56.m

matlab -nojvm -nodisplay -nosplash -r 'tree_57'
rm 57.train_all.dat
rm 57.test_all.dat
rm tree_57.m

matlab -nojvm -nodisplay -nosplash -r 'tree_58'
rm 58.train_all.dat
rm 58.test_all.dat
rm tree_58.m

matlab -nojvm -nodisplay -nosplash -r 'tree_59'
rm 59.train_all.dat
rm 59.test_all.dat
rm tree_59.m

matlab -nojvm -nodisplay -nosplash -r 'tree_60'
rm 60.train_all.dat
rm 60.test_all.dat
rm tree_60.m

matlab -nojvm -nodisplay -nosplash -r 'tree_61'
rm 61.train_all.dat
rm 61.test_all.dat
rm tree_61.m

matlab -nojvm -nodisplay -nosplash -r 'tree_62'
rm 62.train_all.dat
rm 62.test_all.dat
rm tree_62.m

matlab -nojvm -nodisplay -nosplash -r 'tree_63'
rm 63.train_all.dat
rm 63.test_all.dat
rm tree_63.m

matlab -nojvm -nodisplay -nosplash -r 'tree_64'
rm 64.train_all.dat
rm 64.test_all.dat
rm tree_64.m

matlab -nojvm -nodisplay -nosplash -r 'tree_65'
rm 65.train_all.dat
rm 65.test_all.dat
rm tree_65.m

matlab -nojvm -nodisplay -nosplash -r 'tree_66'
rm 66.train_all.dat
rm 66.test_all.dat
rm tree_66.m

matlab -nojvm -nodisplay -nosplash -r 'tree_67'
rm 67.train_all.dat
rm 67.test_all.dat
rm tree_67.m

matlab -nojvm -nodisplay -nosplash -r 'tree_68'
rm 68.train_all.dat
rm 68.test_all.dat
rm tree_68.m

matlab -nojvm -nodisplay -nosplash -r 'tree_69'
rm 69.train_all.dat
rm 69.test_all.dat
rm tree_69.m

matlab -nojvm -nodisplay -nosplash -r 'tree_70'
rm 70.train_all.dat
rm 70.test_all.dat
rm tree_70.m

matlab -nojvm -nodisplay -nosplash -r 'tree_71'
rm 71.train_all.dat
rm 71.test_all.dat
rm tree_71.m

matlab -nojvm -nodisplay -nosplash -r 'tree_72'
rm 72.train_all.dat
rm 72.test_all.dat
rm tree_72.m

matlab -nojvm -nodisplay -nosplash -r 'tree_73'
rm 73.train_all.dat
rm 73.test_all.dat
rm tree_73.m

matlab -nojvm -nodisplay -nosplash -r 'tree_74'
rm 74.train_all.dat
rm 74.test_all.dat
rm tree_74.m

matlab -nojvm -nodisplay -nosplash -r 'tree_75'
rm 75.train_all.dat
rm 75.test_all.dat
rm tree_75.m

matlab -nojvm -nodisplay -nosplash -r 'tree_76'
rm 76.train_all.dat
rm 76.test_all.dat
rm tree_76.m

matlab -nojvm -nodisplay -nosplash -r 'tree_77'
rm 77.train_all.dat
rm 77.test_all.dat
rm tree_77.m

matlab -nojvm -nodisplay -nosplash -r 'tree_78'
rm 78.train_all.dat
rm 78.test_all.dat
rm tree_78.m

matlab -nojvm -nodisplay -nosplash -r 'tree_79'
rm 79.train_all.dat
rm 79.test_all.dat
rm tree_79.m

matlab -nojvm -nodisplay -nosplash -r 'tree_80'
rm 80.train_all.dat
rm 80.test_all.dat
rm tree_80.m

matlab -nojvm -nodisplay -nosplash -r 'tree_81'
rm 81.train_all.dat
rm 81.test_all.dat
rm tree_81.m

matlab -nojvm -nodisplay -nosplash -r 'tree_82'
rm 82.train_all.dat
rm 82.test_all.dat
rm tree_82.m

matlab -nojvm -nodisplay -nosplash -r 'tree_83'
rm 83.train_all.dat
rm 83.test_all.dat
rm tree_83.m

matlab -nojvm -nodisplay -nosplash -r 'tree_84'
rm 84.train_all.dat
rm 84.test_all.dat
rm tree_84.m

matlab -nojvm -nodisplay -nosplash -r 'tree_85'
rm 85.train_all.dat
rm 85.test_all.dat
rm tree_85.m

matlab -nojvm -nodisplay -nosplash -r 'tree_86'
rm 86.train_all.dat
rm 86.test_all.dat
rm tree_86.m

matlab -nojvm -nodisplay -nosplash -r 'tree_87'
rm 87.train_all.dat
rm 87.test_all.dat
rm tree_87.m

matlab -nojvm -nodisplay -nosplash -r 'tree_88'
rm 88.train_all.dat
rm 88.test_all.dat
rm tree_88.m

matlab -nojvm -nodisplay -nosplash -r 'tree_89'
rm 89.train_all.dat
rm 89.test_all.dat
rm tree_89.m

matlab -nojvm -nodisplay -nosplash -r 'tree_90'
rm 90.train_all.dat
rm 90.test_all.dat
rm tree_90.m

matlab -nojvm -nodisplay -nosplash -r 'tree_91'
rm 91.train_all.dat
rm 91.test_all.dat
rm tree_91.m

matlab -nojvm -nodisplay -nosplash -r 'tree_92'
rm 92.train_all.dat
rm 92.test_all.dat
rm tree_92.m

matlab -nojvm -nodisplay -nosplash -r 'tree_93'
rm 93.train_all.dat
rm 93.test_all.dat
rm tree_93.m

matlab -nojvm -nodisplay -nosplash -r 'tree_94'
rm 94.train_all.dat
rm 94.test_all.dat
rm tree_94.m

matlab -nojvm -nodisplay -nosplash -r 'tree_95'
rm 95.train_all.dat
rm 95.test_all.dat
rm tree_95.m

matlab -nojvm -nodisplay -nosplash -r 'tree_96'
rm 96.train_all.dat
rm 96.test_all.dat
rm tree_96.m

matlab -nojvm -nodisplay -nosplash -r 'tree_97'
rm 97.train_all.dat
rm 97.test_all.dat
rm tree_97.m

matlab -nojvm -nodisplay -nosplash -r 'tree_98'
rm 98.train_all.dat
rm 98.test_all.dat
rm tree_98.m

