#!/usr/bin/perl

if (scalar(@ARGV)<1){
        print "perl train_weighted.pl <factor-contribution-individual>\n";
        die;
}

$factor=$ARGV[0];
@target_dir_list=glob "../../TARGET_final_for_check/*"; # a vector containing 21 attribute folder names (../../TARGET_final_for_check/ACID)
$data_file="../../REF/data_0_scaled.txt";
open DATA, $data_file;
while ($line=<DATA>){
#    chomp $line;
#    print "$line\n";
# die;
        chomp $line; # remove the trailling \n ?? Does '\n' usually seperate lines?? How to check that (e.g. \n or \t)?
        @table=split "\t", $line;
#foreach $tmp (@table) {print "$tmp\n";}
#die;
        $name=shift @table;
        if (exists $ref{$name}){ # duplicated ids are only stored once - this is the chemical features, not psochophysical data
                print "same chemical occured twice in data\n";
        }else{
                $i=1;
                foreach $val (@table){
                        $ref{$name}.="\t$val"; # resulting a hash - key is the id number and value is e.g. \t0.1\t0.7\t0\t0.9 
                        $i++; # i is not used here
                }
        }
#print "$i\n";
#print $ref{$name;
#die;
}
close DATA;

@che_list=keys %ref; # 476 CIDs
@che_list=sort{$a<=>$b}@che_list; # ordered by CID

#print "$factor\n";
#foreach $target_name (@che_list) {
#    print "$target_name\n";
#}

$rand=1;
$shrand=1;
@test_list=();
open NEW, ">test_list.txt"; # combine leaderboard and testset into test_list; > create >> append
open TEST, "../../REF/CID_leaderboard.txt" or die;
while ($line=<TEST>){
        chomp $line;
        $line =~ s/\s//g; # sub \s(white spaces) with null
        push @test_list, $line;
        print NEW "$line\n";
}
close TEST;

open TEST, "../../REF/CID_testset.txt" or die;
while ($line=<TEST>){
        chomp $line;
        $line=~s/\s//g;
        push @test_list, $line; # add element at the tail
        print NEW "$line\n";
}
close TEST;
close NEW;

$i=1; # %map is not used..
foreach $aaa (@test_list){
        $map[$i]=$aaa; # why do we need a @map here?? just the index number is the same as the length of test_list; map[0] is empty
        $i++;
#        print "$map[$i-1]\n";
}
#print "$map[0]\n";
#print "$map[1]\n";

foreach $target_dir (@target_dir_list){
#print "$target_dir\n"; # ../../TARGET_final_for_check/ACID
        @t=split '/', $target_dir;
#foreach $tmp (@t) { print "$tmp\n"; }
        $outputfile=pop @t; # pop the last element
        @mat=glob "$target_dir/*"; # ../../TARGET_final_for_check/ACID/1.train


        ## generate train_all for this directory;;

        %value=();  # key: CID; value: sum of values
        %count=();  # key: CID; value: number of counts (NaN is not counted)
        %value_new=(); # what's the differeces between TARGET_final_for_check and TARGET_final_for_check_both ??
        %count_new=();

        foreach $file (@mat){ # ../../TARGET_final_for_check/ACID/1.train 2.train ... 49.train
                open FILE, "$file" or die;
                while ($line=<FILE>){
                        chomp $line;
                        @table=split "\t", $line;
                        if ($table[1] eq "NaN"){ # ignore NaN cases
                        }else{
                                $value{$table[0]}+=$table[1];
                                $count{$table[0]}++;
                        }
                }
                close FILE;

                $newfile=$file;
                $newfile=~s/TARGET_final_for_check/TARGET_final_for_check_both/g;

                open FILE, "$newfile" or die;
                while ($line=<FILE>){
                        chomp $line;
                        @table=split "\t", $line;
                        if ($table[1] eq "NaN"){
                        }else{
                                $value_new{$table[0]}+=$table[1];
                                $count_new{$table[0]}++;
                        }
                }
	}

        foreach $file (@mat){ # ../../TARGET_final_for_check/ACID/1.train 2.train ... 49.train
                open TRAIN, ">${rand}.train_all.dat" or die;
                open TEST, ">${rand}.test_all.dat" or die;


                open FILE, "$file" or die;
                %test=();  # key: CID; value: one value in *.train
                while ($line=<FILE>){
                        chomp $line;
                        @table=split "\t", $line;
                        if ($table[1] eq "NaN"){}else{
                                $test{$table[0]}=$table[1];
                        }
                }
                close FILE;


                $newfile=$file;
                $newfile=~s/TARGET_final_for_check/TARGET_final_for_check_both/g;
                open FILE, "$newfile" or die;
                %test_new=();
                while ($line=<FILE>){
                        chomp $line;
                        @table=split "\t", $line;
                        if ($table[1] eq "NaN"){}else{
                                $test_new{$table[0]}=$table[1];
                        }
                }
                close FILE;

                foreach $che (@che_list){
                        if (defined $value{$che}){
                                if (defined $test{$che}){
                                        $test_val=$test{$che};
                                }else{

                                        $test_val=0;
                                }
                                $ratio=(scalar(keys %test))/(scalar(keys %value))*$factor;

                                $val=(1-$ratio)*$value{$che}/$count{$che}+$ratio*$test_val;
                                print TRAIN "$val";
                                @t=split "\t", $ref{$che};
                                shift @t; # $ref{$che} is \t0.1\t0.3\t0.9, then @t has 4 elements and $t[0] is null - that's why we need a shift here
                                $i=1;
                                foreach $aaa (@t){
                                        print TRAIN "\t$aaa";
                                        $i++;
                                }

                                print TRAIN "\n";  # 1.train_all.dat is $val\t0.1\t0.3\t0.9 ... \t0.4\n (3084 columns for all 476 molecules)
                        }
                        if (($file=~/INTENSITY/)||($file=~/VALENCE/)){}else{  # if it is intensity or valence, do nothing. Why is it different for test_new??
                        $ratio=(scalar(keys %test_new))/(scalar(keys %value_new))*$factor;
                        if (defined $value_new{$che}){
                                if (defined $test_new{$che}){
                                        $test_val=$test_new{$che};
                                }else{

                                        $test_val=0;
                                }

                                $val=(1-$ratio)*$value_new{$che}/$count_new{$che}+$ratio*$test_val;
                                print TRAIN "$val";
                                @t=split "\t", $ref{$che};
                                shift @t;
                                $i=1;
                                foreach $aaa (@t){  # why print the 3083 chemical features twices - double the sample size!
                                        print TRAIN "\t$aaa";
                                        $i++;
                                }

                                print TRAIN "\n"; 
                        }
                        }
                }
                foreach $che (@test_list){
                                print TEST "0";
                                @t=split "\t", $ref{$che};
                                shift @t;
                                $i=1;
                                foreach $aaa (@t){
                                        print TEST "\t$aaa"; # 1.test_all.dat is 0\t0.1\t0.3\t0.9 ... \t0.4\n (3084 columes for 138 test molecules
                                        $i++;
                                }

                                print TEST "\n";
                }
                close TRAIN;
                close TEST;

                @t=split '/', $file;
                $id=pop @t; # 1.train
                $des=pop @t; # ACID
                @t=split '\.train', $id;
                $id=shift @t; # 1

                open TREE, ">tree_${rand}.m" or die;
                print TREE "
                        train=load('${rand}.train_all.dat');
                        test=load('${rand}.test_all.dat');
                        n_column=size(train,2);

                        y_train_target=train(:,1);
                        y_train_data=train(:,2:n_column);
                        B = TreeBagger(100,y_train_data,y_train_target,'method','regression');
                        y_test_data=test(:,2:n_column);
                         pred=B.predict(y_test_data);
                        save 'result/${des}.${id}.result' pred -ASCII
                        exit;
                ";
                close TREE;

                open BASH, ">>${shrand}.sh" or die;
                print BASH "matlab -nojvm -nodisplay -nosplash -r '"; print BASH "tree_${rand}"; print BASH "'\n";
                print BASH "rm ${rand}.train_all.dat\n";
                print BASH "rm ${rand}.test_all.dat\n";
                print BASH "rm tree_${rand}.m\n\n";
                close BASH;
                $rand++;


                $des_list{$des}=0; # %des_list and %id_list are not used ..
                $id_list{$id}=0;

	}
        system "chmod +x ${shrand}.sh";
        $shrand++;
}
# $ shrand 21 files (for 21 features)
# $ rand 21 * 49; each bash 1.sh file contain tree_1-49.m; tree_50-98.m; tree_99-147.m ...

$i=1;
while ($i<$shrand){

        system "./${i}.sh";
        $i++;
}

