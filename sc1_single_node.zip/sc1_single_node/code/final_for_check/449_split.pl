#!/usr/bin/perl

@test_list=();

open LIST, "test_list.txt" or die;
while ($line=<LIST>){
        chomp $line;
        push @test_list, $line;
}
close LIST;

@mat=glob "result/*";
foreach $file (@mat){
        @t=split "/", $file;
        @t=split '\.', $t[1];
        $d=$t[0]; # ACID
        $pid=$t[1]; # 1
        open FILE, "$file" or die;
        foreach $cid (@test_list){
                $line=<FILE>;
                chomp $line;
                $line=~s/\s\s*//g; # What's this?? There are 3 whitespaces in each row in result/ACID.1.result files
                $ref{$cid}{$d}{$pid}=$line; # hashes of hashes
                $chem{$cid}=0;
                $des{$d}=0;
        }
        close FILE;
}

open TEST, "../../REF/CID_leaderboard.txt" or die;
while ($line=<TEST>){
        chomp $line;
        $line=~s/\s//g;
        $leaderboard{$line}=0;
}
close TEST;

open TEST, "../../REF/CID_testset.txt" or die;
while ($line=<TEST>){
        chomp $line;
        $line=~s/\s//g;
        $finaltest{$line}=0;
}
close TEST;

open LED, ">sc01_leaderboard_set1.txt" or die;
open TEST, ">sc01_finaltest_set1.txt" or die;
print LED "#oID\tindividual\tdescriptor\tvalue\n";
print TEST "#oID\tindividual\tdescriptor\tvalue\n";
@chem_list=keys %chem;
@des_list=keys %des;

foreach $che (@chem_list){
        if (exists $leaderboard{$che}){


                foreach $des (@des_list){
                        $olddes=$des;
                        if ($olddes eq "INTENSITY"){
                                $olddes='INTENSITY/STRENGTH';
                        }
                        $olddes=~s/_/\//g;
                        $i=1;
                        while ($i<50){
                                $val=$ref{$che}{$des}{$i};;
                                print LED "$che\t$i\t$olddes\t$val\n";
                                $i++;
                        }
                }


        }elsif (exists $finaltest{$che}){

                foreach $des (@des_list){
                        $olddes=$des;
                        if ($olddes eq "INTENSITY"){
                                $olddes='INTENSITY/STRENGTH';
                        }
                        $olddes=~s/_/\//g;
                        $i=1;
                        while ($i<50){
                                $val=$ref{$che}{$des}{$i};
                                print TEST "$che\t$i\t$olddes\t$val\n";
                                $i++;
                        }
                }
        }
}
close TEST;
close LEARDERBOARD;
close TRAIN; # delete this line ..




