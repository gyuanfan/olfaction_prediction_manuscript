#!/usr/bin/perl
#
mkdir REF;

open FILE, "/home/gyuanfan/2015/OP/rawdata/TrainSet.final.txt" or die;
open NEW, ">REF/train_chem.list" or die;
open ID, ">REF/train_id.list" or die;
# remove title line;
<FILE>;

%ex=();
%id=();
while ($line=<FILE>){
	chomp $line;
	@table=split "\t", $line;
	if (exists $ex{$table[0]}){
	}else{
		print NEW "$table[0]\n";
		$ex{$table[0]}=0;
	}

	if (exists $id{$table[5]}){
	}else{
		print ID "$table[5]\n";
		$id{$table[5]}=0;
	}


}
close FILE;
close NEW;
close ID;

	
