#!/usr/bin/perl
#
#Take the average of 1/1000 dilutions.
# for each individual, prepare a target file;
system "mkdir TARGET_final_for_check";

system "mkdir TARGET_final_for_check/INTENSITY";

open OLD, "/home/gyuanfan/2015/OP/rawdata/TrainSet.final.txt" or die;
## remove title line;

$line=<OLD>;
while ($line=<OLD>){
	chomp $line;
	@table=split "\t", $line;
	if ($table[4] eq "\"1\/1,000\""){
		if ($table[2] =~/replicate/){
			$che_count_rep{$table[0]}{$table[5]}++;
			$che_sum_rep{$table[0]}{$table[5]}+=$table[6];
		}else{
			$che_count{$table[0]}{$table[5]}++;
			$che_sum{$table[0]}{$table[5]}+=$table[6];
		}
	}

}
close OLD;
	
@che_list=();
open REF_CHE, "REF/train_chem.list" or die;
while ($line=<REF_CHE>){
	chomp $line;
	push @che_list, $line;
}
close REF_CHE;


@id_list=();
open REF_ID, "REF/train_id.list" or die;
while ($line=<REF_ID>){
	chomp $line;
	push @id_list, $line;
}
close REF_ID;

	
foreach $id (@id_list){
	open NEW, ">TARGET_final_for_check/INTENSITY/${id}.train" or die;
	foreach $che (@che_list){
		if (exists $che_count{$che}{$id}){
			$che_val=$che_sum{$che}{$id}/$che_count{$che}{$id};
			print NEW "$che\t$che_val\n";
		}else{
			print "$che\t$id\n";
		}
		if (exists $che_count_rep{$che}{$id}){
			$che_val=$che_sum_rep{$che}{$id}/$che_count_rep{$che}{$id};
			print NEW "$che\t$che_val\n";
		}
	}
	close NEW;
}
