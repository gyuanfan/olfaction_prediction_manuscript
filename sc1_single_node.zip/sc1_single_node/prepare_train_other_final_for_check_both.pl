#!/usr/bin/perl
#
#Take the average of 1/1000 dilutions.
# for each individual, prepare a target file;

open OLD, "/home/gyuanfan/2015/OP/rawdata/TrainSet.final.txt" or die;
## remove title line;

$line=<OLD>;
chomp $line;
$line=~s/\//_/g;
@title=split "\t", $line;
$i=7;
while ($i<=26){
	system "mkdir TARGET_final_for_check_both/$title[$i]";
	$i++;
}


while ($line=<OLD>){
	chomp $line;
	@table=split "\t", $line;
	#if ($table[3] =~/high/){
		$i=7;
		while ($i<=26){
			if ($table[$i] eq "NaN"){}else{
				$che_sum{$table[0]}{$table[5]}{$title[$i]}+=$table[$i];
				$che_count{$table[0]}{$table[5]}{$title[$i]}++;
			}
			
			$i++;
		}
	#}

}
close OLD;
	
@che_list=();
open REF_CHE, "REF/train_chem.list" or die;
while ($line=<REF_CHE>){
	chomp $line;
	push @che_list, $line;
}
close REF_CHE;


@id_list=();
open REF_ID, "REF/train_id.list" or die;
while ($line=<REF_ID>){
	chomp $line;
	push @id_list, $line;
}
close REF_ID;

	
$i=7;
while ($i<=26){
	foreach $id (@id_list){
		open NEW, ">TARGET_final_for_check_both/$title[$i]/${id}.train" or die;
		foreach $che (@che_list){
			if (exists $che_sum{$che}{$id}{$title[$i]}){
				$che_val=($che_sum{$che}{$id}{$title[$i]})/($che_count{$che}{$id}{$title[$i]});
				print NEW "$che\t$che_val\n";
			}else{
				print "$che\t$id\n";
			}
		}
		close NEW;
	}
	$i++;
}

