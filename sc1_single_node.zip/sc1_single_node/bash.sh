#!/usr/bin

cd code/final_for_check/
perl train_weighted_final.pl 0.2
perl split_final_prediction.pl

cd ../final_for_check_name/
perl train_weighted_final.pl 0.2
perl split_final_prediction.pl

cd ../../
perl combine_final_for_check_01.pl ./code/final_for_check/sc01_finaltest_set1.txt ./code/final_for_check_name/sc01_finaltest_set2.txt sc01_submission.txt

