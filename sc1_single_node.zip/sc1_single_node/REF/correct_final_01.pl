#!/usr/bin/perl
#
($in,$out)=($ARGV[0],$ARGV[1]);

@list=('196','239','243','262','311','750','962','1030','1110','5780','5950','6322','8042','33032','444972');

foreach $aaa (@list){
	$zero{$aaa}=0;
}


open IN, "$in" or die;
<IN>;
while ($line=<IN>){
	chomp $line;
	@table=split "\t", $line;
	if (exists $ref{$table[1]}{$table[2]}){
		if ($table[3]<$ref{$table[1]}{$table[2]}){
			$ref{$table[1]}{$table[2]}=$table[3];
		}
	}else{
		$ref{$table[1]}{$table[2]}=$table[3];
	}
		
}
close IN;

			
open IN, "$in" or die;
open OUT, ">$out" or die;
$line=<IN>;
print OUT "$line";
while ($line=<IN>){
	chomp $line;
	@table=split "\t", $line;
	if ($line=~/INTENSITY/){
		if (exists $zero{$table[0]}){
			print OUT "$table[0]\t$table[1]\t$table[2]\t$ref{$table[1]}{$table[2]}\n";
	
		}
		else{
			print OUT "$line\n";
		}
	}else{
			print OUT "$line\n";
	}
}
close IN;
close OUT;

