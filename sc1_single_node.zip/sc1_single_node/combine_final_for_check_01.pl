#!/usr/bin/perl
###
#
## first file: original prediction;
## second file: name predictions;
($in1,$in2,$in3)=($ARGV[0],$ARGV[1],$ARGV[2]);
open OLD2, "$in2" or die;
<OLD2>;
while ($line=<OLD2>){
	chomp $line;
	@table=split "\t", $line;
	$value{$table[0]}{$table[1]}{$table[2]}=$table[3];
}
close OLD2;


open NEW, ">tmp.txt" or die;
open OLD1, "$in1" or die;
$line1=<OLD1>;
print NEW $line1;
while ($line=<OLD1>){
	chomp $line;
	@table=split "\t", $line;
	print NEW "$table[0]\t$table[1]\t$table[2]\t";
	if ($table[2]=~/INTENSITY/){
		print NEW "$table[3]\n";
	}else{
		if (exists $value{$table[0]}{$table[1]}{$table[2]}){
			$avg=($table[3]+$value{$table[0]}{$table[1]}{$table[2]})/2;
			print NEW "$avg\n";
		}else{
		
			print NEW "$table[3]\n";
		}
	}
}

	
	
system "perl REF/correct_final_01.pl tmp.txt $ARGV[2]";
